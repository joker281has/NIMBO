import React from 'react';
import { 
  Cpu, 
  Cloud, 
  Shield, 
  Code, 
  LineChart, 
  Briefcase, 
  Rocket, 
  Headphones, 
  Notebook, 
  Microscope, 
  Zap, 
  Smartphone, 
  Wrench, 
  ShieldCheck, 
  Database, 
  Globe 
} from 'lucide-react';
import type { ServiceItem } from '../types/services';

export const coreServices: ServiceItem[] = [
  {
    icon: <Cpu className="w-6 h-6 text-nimbo-orange" />,
    name: "AI & Machine Learning",
    description: "Advanced AI solutions for business automation",
    path: "/services/ai-ml"
  },
  {
    icon: <Cloud className="w-6 h-6 text-nimbo-orange" />,
    name: "Cloud Infrastructure",
    description: "Scalable cloud hosting and deployment",
    path: "/services/cloud"
  },
  {
    icon: <Shield className="w-6 h-6 text-nimbo-orange" />,
    name: "Cybersecurity",
    description: "Enterprise-grade security solutions",
    path: "/services/security"
  },
  {
    icon: <Code className="w-6 h-6 text-nimbo-orange" />,
    name: "Software Development",
    description: "Custom software solutions and integrations",
    path: "/services/development"
  }
];

export const businessServices: ServiceItem[] = [
  {
    icon: <LineChart className="w-6 h-6 text-nimbo-orange" />,
    name: "Business Intelligence",
    description: "Data-driven insights and analytics",
    path: "/services/analytics"
  },
  {
    icon: <Briefcase className="w-6 h-6 text-nimbo-orange" />,
    name: "Enterprise Solutions",
    description: "Comprehensive business management systems",
    path: "/services/enterprise"
  },
  {
    icon: <Rocket className="w-6 h-6 text-nimbo-orange" />,
    name: "Digital Transformation",
    description: "Modernize your business operations",
    path: "/services/transformation"
  },
  {
    icon: <Headphones className="w-6 h-6 text-nimbo-orange" />,
    name: "24/7 Support",
    description: "Round-the-clock technical assistance",
    path: "/services/support"
  }
];

export const innovationServices: ServiceItem[] = [
  {
    icon: <Notebook className="w-6 h-6 text-nimbo-orange" />,
    name: "Robotics & Automation",
    description: "Advanced robotics and process automation",
    path: "/services/robotics"
  },
  {
    icon: <Microscope className="w-6 h-6 text-nimbo-orange" />,
    name: "R&D Labs",
    description: "Cutting-edge research and development",
    path: "/services/research"
  },
  {
    icon: <Zap className="w-6 h-6 text-nimbo-orange" />,
    name: "Innovation Consulting",
    description: "Strategic technology consulting",
    path: "/services/innovation"
  },
  {
    icon: <Smartphone className="w-6 h-6 text-nimbo-orange" />,
    name: "Mobile Solutions",
    description: "Cross-platform mobile development",
    path: "/services/mobile"
  }
];

export const itServices: ServiceItem[] = [
  {
    icon: <Wrench className="w-6 h-6 text-nimbo-orange" />,
    name: "IT Infrastructure",
    description: "Complete IT setup and maintenance",
    path: "/services/infrastructure"
  },
  {
    icon: <ShieldCheck className="w-6 h-6 text-nimbo-orange" />,
    name: "Network Security",
    description: "Secure network architecture and monitoring",
    path: "/services/network"
  },
  {
    icon: <Database className="w-6 h-6 text-nimbo-orange" />,
    name: "Data Management",
    description: "Database solutions and optimization",
    path: "/services/data"
  },
  {
    icon: <Globe className="w-6 h-6 text-nimbo-orange" />,
    name: "Cloud Migration",
    description: "Seamless transition to cloud platforms",
    path: "/services/migration"
  }
];
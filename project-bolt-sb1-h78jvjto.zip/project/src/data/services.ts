import type { ServiceItem } from '../types/services';

export const coreServices: ServiceItem[] = [
  {
    name: "AI & Machine Learning",
    description: "Advanced AI solutions for business automation",
    path: "/services/ai-ml"
  },
  {
    name: "Cloud Infrastructure",
    description: "Scalable cloud hosting and deployment",
    path: "/services/cloud"
  },
  {
    name: "Cybersecurity",
    description: "Enterprise-grade security solutions",
    path: "/services/security"
  },
  {
    name: "Software Development",
    description: "Custom software solutions and integrations",
    path: "/services/development"
  }
];

export const businessServices: ServiceItem[] = [
  {
    name: "Business Intelligence",
    description: "Data-driven insights and analytics",
    path: "/services/analytics"
  },
  {
    name: "Enterprise Solutions",
    description: "Comprehensive business management systems",
    path: "/services/enterprise"
  },
  {
    name: "Digital Transformation",
    description: "Modernize your business operations",
    path: "/services/transformation"
  },
  {
    name: "24/7 Support",
    description: "Round-the-clock technical assistance",
    path: "/services/support"
  }
];

export const innovationServices: ServiceItem[] = [
  {
    name: "Robotics & Automation",
    description: "Advanced robotics and process automation",
    path: "/services/robotics"
  },
  {
    name: "R&D Labs",
    description: "Cutting-edge research and development",
    path: "/services/research"
  },
  {
    name: "Innovation Consulting",
    description: "Strategic technology consulting",
    path: "/services/innovation"
  },
  {
    name: "Mobile Solutions",
    description: "Cross-platform mobile development",
    path: "/services/mobile"
  }
];

export const itServices: ServiceItem[] = [
  {
    name: "IT Infrastructure",
    description: "Complete IT setup and maintenance",
    path: "/services/infrastructure"
  },
  {
    name: "Network Security",
    description: "Secure network architecture and monitoring",
    path: "/services/network"
  },
  {
    name: "Data Management",
    description: "Database solutions and optimization",
    path: "/services/data"
  },
  {
    name: "Cloud Migration",
    description: "Seamless transition to cloud platforms",
    path: "/services/migration"
  }
];
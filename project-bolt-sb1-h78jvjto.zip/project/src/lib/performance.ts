import { getCLS, getFID, getLCP, getFCP, getTTFB } from 'web-vitals';
import { captureError } from './sentry';

function sendToAnalytics({ name, delta, id }: { name: string; delta: number; id: string }) {
  try {
    if (typeof window.gtag !== 'undefined') {
      window.gtag('event', name, {
        event_category: 'Web Vitals',
        event_label: id,
        value: Math.round(name === 'CLS' ? delta * 1000 : delta),
        non_interaction: true,
      });
    }
  } catch (error) {
    captureError(error as Error, { context: 'Web Vitals Reporting' });
  }
}

export function initPerformanceMonitoring() {
  try {
    getCLS(sendToAnalytics);
    getFID(sendToAnalytics);
    getLCP(sendToAnalytics);
    getFCP(sendToAnalytics);
    getTTFB(sendToAnalytics);
  } catch (error) {
    captureError(error as Error, { context: 'Performance Monitoring Init' });
  }
}
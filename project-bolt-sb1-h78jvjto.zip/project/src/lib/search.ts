import Fuse from 'fuse.js';

interface SearchableItem {
  id: string;
  name: string;
  description: string;
  tags?: string[];
}

export class SearchService {
  private fuse: Fuse<SearchableItem>;

  constructor(items: SearchableItem[]) {
    this.fuse = new Fuse(items, {
      keys: ['name', 'description', 'tags'],
      threshold: 0.3,
      includeScore: true
    });
  }

  search(query: string) {
    return this.fuse.search(query);
  }

  addItem(item: SearchableItem) {
    this.fuse.add(item);
  }

  removeItem(id: string) {
    this.fuse.remove((doc) => doc.id === id);
  }

  updateItem(item: SearchableItem) {
    this.removeItem(item.id);
    this.addItem(item);
  }
}

export function filterItems<T extends Record<string, any>>(
  items: T[],
  filters: Record<string, any>
) {
  return items.filter((item) =>
    Object.entries(filters).every(([key, value]) => {
      if (Array.isArray(value)) {
        return value.includes(item[key]);
      }
      if (typeof value === 'object' && value !== null) {
        const { min, max } = value;
        const itemValue = item[key];
        return (!min || itemValue >= min) && (!max || itemValue <= max);
      }
      return item[key] === value;
    })
  );
}
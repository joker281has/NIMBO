import { supabase } from './supabase';

interface EmailData {
  to: string;
  subject: string;
  template: string;
  data: Record<string, any>;
}

export async function sendEmail({ to, subject, template, data }: EmailData) {
  try {
    // In production, integrate with your email service provider
    // For now, log the email data
    console.log('Sending email:', {
      to,
      subject,
      template,
      data
    });

    // Store email in database for tracking
    await supabase
      .from('emails')
      .insert([
        {
          recipient: to,
          subject,
          template,
          data,
          status: 'pending'
        }
      ]);

    return { success: true };
  } catch (error) {
    console.error('Failed to send email:', error);
    return { success: false, error };
  }
}
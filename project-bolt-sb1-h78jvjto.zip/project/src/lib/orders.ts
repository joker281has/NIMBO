import { supabase } from './supabase';
import { format } from 'date-fns';

export interface Order {
  id: string;
  userId: string;
  items: {
    id: string;
    name: string;
    quantity: number;
    price: number;
  }[];
  total: number;
  status: 'pending' | 'processing' | 'shipped' | 'delivered' | 'cancelled';
  createdAt: string;
  updatedAt: string;
  shippingAddress: {
    name: string;
    street: string;
    city: string;
    state: string;
    zip: string;
    country: string;
  };
}

export async function getOrders(userId: string) {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data as Order[];
}

export async function getOrder(orderId: string) {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('id', orderId)
    .single();

  if (error) throw error;
  return data as Order;
}

export async function createOrder(order: Omit<Order, 'id' | 'createdAt' | 'updatedAt'>) {
  const { data, error } = await supabase
    .from('orders')
    .insert([
      {
        ...order,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }
    ])
    .select()
    .single();

  if (error) throw error;
  return data as Order;
}

export function formatOrderDate(date: string) {
  return format(new Date(date), 'PPP');
}

export function getOrderStatus(status: Order['status']) {
  const statusMap = {
    pending: { label: 'Pending', color: 'text-yellow-500' },
    processing: { label: 'Processing', color: 'text-blue-500' },
    shipped: { label: 'Shipped', color: 'text-purple-500' },
    delivered: { label: 'Delivered', color: 'text-green-500' },
    cancelled: { label: 'Cancelled', color: 'text-red-500' }
  };

  return statusMap[status];
}
import { getCLS, getFID, getLCP, getFCP, getTTFB } from 'web-vitals';

interface Metric {
  name: string;
  value: number;
  delta: number;
  id: string;
  entries: PerformanceEntry[];
}

function sendToAnalytics(metric: Metric) {
  // In production, send to your analytics service
  console.log('Performance metric:', metric);

  if (typeof window.gtag !== 'undefined') {
    window.gtag('event', 'web_vitals', {
      event_category: 'Web Vitals',
      event_label: metric.name,
      value: Math.round(metric.name === 'CLS' ? metric.value * 1000 : metric.value),
      non_interaction: true,
    });
  }
}

export function initializeMonitoring() {
  getCLS(sendToAnalytics);
  getFID(sendToAnalytics);
  getLCP(sendToAnalytics);
  getFCP(sendToAnalytics);
  getTTFB(sendToAnalytics);

  // Error tracking
  window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    // In production, send to error tracking service
  });

  window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    // In production, send to error tracking service
  });
}
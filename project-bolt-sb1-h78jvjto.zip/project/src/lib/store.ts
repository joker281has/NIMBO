import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
}

interface WishlistItem {
  id: string;
  name: string;
  price: number;
  addedAt: string;
}

interface UserPreferences {
  theme: 'light' | 'dark';
  notifications: boolean;
  currency: string;
}

interface StoreState {
  cart: CartItem[];
  wishlist: WishlistItem[];
  preferences: UserPreferences;
  addToCart: (item: Omit<CartItem, 'quantity'>) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  addToWishlist: (item: Omit<WishlistItem, 'addedAt'>) => void;
  removeFromWishlist: (id: string) => void;
  updatePreferences: (preferences: Partial<UserPreferences>) => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set) => ({
      cart: [],
      wishlist: [],
      preferences: {
        theme: 'dark',
        notifications: true,
        currency: 'USD'
      },
      addToCart: (item) =>
        set((state) => {
          const existingItem = state.cart.find((i) => i.id === item.id);
          if (existingItem) {
            return {
              cart: state.cart.map((i) =>
                i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i
              )
            };
          }
          return { cart: [...state.cart, { ...item, quantity: 1 }] };
        }),
      removeFromCart: (id) =>
        set((state) => ({
          cart: state.cart.filter((item) => item.id !== id)
        })),
      updateQuantity: (id, quantity) =>
        set((state) => ({
          cart: state.cart.map((item) =>
            item.id === id ? { ...item, quantity } : item
          )
        })),
      clearCart: () => set({ cart: [] }),
      addToWishlist: (item) =>
        set((state) => ({
          wishlist: [
            ...state.wishlist,
            { ...item, addedAt: new Date().toISOString() }
          ]
        })),
      removeFromWishlist: (id) =>
        set((state) => ({
          wishlist: state.wishlist.filter((item) => item.id !== id)
        })),
      updatePreferences: (preferences) =>
        set((state) => ({
          preferences: { ...state.preferences, ...preferences }
        }))
    }),
    {
      name: 'nimbo-store'
    }
  )
);
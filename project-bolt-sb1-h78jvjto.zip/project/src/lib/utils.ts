export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
}

export function generateId(): string {
  return Math.random().toString(36).substring(2) + Date.now().toString(36);
}
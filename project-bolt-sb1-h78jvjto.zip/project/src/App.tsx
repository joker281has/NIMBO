import React, { useState, useEffect, useCallback } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, Navigate, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import FloatingServer from './components/FloatingServer';
import GradientBackground from './components/GradientBackground';
import SignIn from './pages/SignIn';
import SignUp from './pages/SignUp';
import Dashboard from './pages/Dashboard';
import Home from './pages/Home';
import ServicePage from './pages/services';
import Consultation from './pages/Consultation';
import { supabase } from './lib/supabase';
import NimboLogo from './components/NimboLogo';
import ServiceDropdown from './components/ServiceDropdown';
import { coreServices, businessServices, innovationServices, itServices } from './data/services';

function AppContent() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  // Close menu on route change
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  // Prevent body scroll when menu is open
  useEffect(() => {
    if (isMenuOpen) {
      document.body.style.overflow = 'hidden';
      document.body.style.touchAction = 'none';
    } else {
      document.body.style.overflow = '';
      document.body.style.touchAction = '';
    }
    return () => {
      document.body.style.overflow = '';
      document.body.style.touchAction = '';
    };
  }, [isMenuOpen]);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleScroll = useCallback(() => {
    setScrolled(window.scrollY > 50);
  }, []);

  useEffect(() => {
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [handleScroll]);

  if (loading) {
    return (
      <div className="min-h-screen bg-nimbo-dark flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-nimbo-orange"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-nimbo-dark text-white">
      <header 
        className={`fixed w-full z-50 transition-all duration-300 ${
          scrolled ? 'bg-nimbo-dark/90 backdrop-blur-lg shadow-lg' : ''
        }`}
      >
        <nav className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-2 z-50">
              <NimboLogo />
            </Link>

            <div className="hidden md:flex items-center space-x-8">
              <ServiceDropdown title="Core Services" items={coreServices} />
              <ServiceDropdown title="Business" items={businessServices} />
              <ServiceDropdown title="Innovation" items={innovationServices} />
              <ServiceDropdown title="IT Services" items={itServices} />
              <Link 
                to="/consultation" 
                className="hover:text-nimbo-orange transition-colors"
              >
                Book Consultation
              </Link>
              {user ? (
                <>
                  <Link to="/dashboard" className="hover:text-nimbo-orange transition-colors">Dashboard</Link>
                  <button 
                    onClick={() => supabase.auth.signOut()} 
                    className="px-4 py-2 rounded-lg bg-nimbo-dark-lighter hover:bg-nimbo-dark-light transition-colors"
                  >
                    Sign Out
                  </button>
                </>
              ) : (
                <>
                  <Link to="/signin" className="hover:text-nimbo-orange transition-colors">Sign In</Link>
                  <Link 
                    to="/signup" 
                    className="px-4 py-2 rounded-lg bg-nimbo-orange hover:bg-nimbo-orange-light transition-colors"
                  >
                    Get Started
                  </Link>
                </>
              )}
            </div>

            <button 
              className="md:hidden p-2 hover:bg-nimbo-dark-lighter rounded-lg transition-colors z-50"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </nav>

        {/* Mobile Menu with improved transitions and touch handling */}
        <div 
          className={`fixed inset-0 bg-nimbo-dark transform transition-transform duration-300 ease-in-out md:hidden ${
            isMenuOpen ? 'translate-x-0' : 'translate-x-full'
          }`}
          style={{ top: '0', zIndex: 40 }}
        >
          <div className="h-full overflow-y-auto overscroll-contain pt-20 pb-6">
            <div className="container mx-auto px-4 space-y-6">
              {/* Core Services */}
              <div>
                <h3 className="text-sm font-semibold text-gray-400 mb-2">Core Services</h3>
                <div className="grid grid-cols-1 gap-2">
                  {coreServices.map(renderMobileMenuItem)}
                </div>
              </div>

              {/* Business Services */}
              <div>
                <h3 className="text-sm font-semibold text-gray-400 mb-2">Business</h3>
                <div className="grid grid-cols-1 gap-2">
                  {businessServices.map(renderMobileMenuItem)}
                </div>
              </div>

              {/* Innovation Services */}
              <div>
                <h3 className="text-sm font-semibold text-gray-400 mb-2">Innovation</h3>
                <div className="grid grid-cols-1 gap-2">
                  {innovationServices.map(renderMobileMenuItem)}
                </div>
              </div>

              {/* IT Services */}
              <div>
                <h3 className="text-sm font-semibold text-gray-400 mb-2">IT Services</h3>
                <div className="grid grid-cols-1 gap-2">
                  {itServices.map(renderMobileMenuItem)}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-3 pt-4 border-t border-nimbo-dark">
                <Link 
                  to="/consultation" 
                  className="block px-4 py-3 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-lg text-center transition-colors active:bg-nimbo-orange-light"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Book Consultation
                </Link>

                {user ? (
                  <>
                    <Link 
                      to="/dashboard" 
                      className="block px-4 py-3 hover:bg-nimbo-dark rounded-lg text-center transition-colors active:bg-nimbo-dark-lighter"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Dashboard
                    </Link>
                    <button 
                      onClick={() => {
                        supabase.auth.signOut();
                        setIsMenuOpen(false);
                      }} 
                      className="w-full px-4 py-3 rounded-lg bg-nimbo-dark hover:bg-nimbo-dark-light transition-colors active:bg-nimbo-dark-lighter"
                    >
                      Sign Out
                    </button>
                  </>
                ) : (
                  <>
                    <Link 
                      to="/signin" 
                      className="block px-4 py-3 hover:bg-nimbo-dark rounded-lg text-center transition-colors active:bg-nimbo-dark-lighter"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Sign In
                    </Link>
                    <Link 
                      to="/signup" 
                      className="block px-4 py-3 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-lg text-center transition-colors active:bg-nimbo-orange-light"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      Get Started
                    </Link>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="pt-20">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/signin" element={user ? <Navigate to="/dashboard" /> : <SignIn />} />
          <Route path="/signup" element={user ? <Navigate to="/dashboard" /> : <SignUp />} />
          <Route path="/dashboard" element={user ? <Dashboard /> : <Navigate to="/signin" />} />
          <Route path="/services/:serviceId" element={<ServicePage />} />
          <Route path="/consultation" element={<Consultation />} />
        </Routes>
      </main>

      <footer className="bg-nimbo-dark-lighter mt-20">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <NimboLogo className="w-10 h-10" />
              </div>
              <p className="text-gray-400">The future of cloud computing</p>
            </div>
            
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/features" className="hover:text-white">Features</Link></li>
                <li><Link to="/pricing" className="hover:text-white">Pricing</Link></li>
                <li><Link to="/docs" className="hover:text-white">Documentation</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/about" className="hover:text-white">About</Link></li>
                <li><Link to="/blog" className="hover:text-white">Blog</Link></li>
                <li><Link to="/careers" className="hover:text-white">Careers</Link></li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to="/privacy" className="hover:text-white">Privacy Policy</Link></li>
                <li><Link to="/terms" className="hover:text-white">Terms of Service</Link></li>
              </ul>
            </div>
          </div>

          <div className="border-t border-nimbo-dark-lighter mt-12 pt-8 text-center text-gray-400">
            <p>&copy; {new Date().getFullYear()} Nimbo. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

const renderMobileMenuItem = (service: ServiceItem) => (
  <Link
    key={service.path}
    to={service.path}
    className="flex items-center space-x-3 p-3 rounded-lg hover:bg-nimbo-dark transition-colors active:bg-nimbo-dark-lighter"
  >
    <div>
      <span className="font-medium">{service.name}</span>
      <p className="text-sm text-gray-400">{service.description}</p>
    </div>
  </Link>
);

export default function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}
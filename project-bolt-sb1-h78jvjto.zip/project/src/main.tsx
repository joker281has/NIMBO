import React from 'react';
import ReactDOM from 'react-dom';
import { createRoot } from 'react-dom/client';
import { HelmetProvider } from 'react-helmet-async';
import { initSentry } from './lib/sentry';
import { initPerformanceMonitoring } from './lib/performance';
import ErrorBoundary from './components/ErrorBoundary';
import App from './App';
import './index.css';

// Initialize monitoring
initSentry();
initPerformanceMonitoring();

// Add axe-core in development
if (import.meta.env.DEV) {
  const axe = await import('@axe-core/react');
  axe.default(React, ReactDOM, 1000);
}

createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <ErrorBoundary>
      <HelmetProvider>
        <App />
      </HelmetProvider>
    </ErrorBoundary>
  </React.StrictMode>
);
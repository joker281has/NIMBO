import { Loader2 } from 'lucide-react';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  fullScreen?: boolean;
}

export default function LoadingSpinner({ size = 'md', fullScreen = false }: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-8 h-8',
    lg: 'w-12 h-12'
  };

  if (fullScreen) {
    return (
      <div className="fixed inset-0 bg-nimbo-dark/80 backdrop-blur-sm flex items-center justify-center z-50">
        <Loader2 className={`${sizeClasses[size]} text-nimbo-orange animate-spin`} />
      </div>
    );
  }

  return <Loader2 className={`${sizeClasses[size]} text-nimbo-orange animate-spin`} />;
}
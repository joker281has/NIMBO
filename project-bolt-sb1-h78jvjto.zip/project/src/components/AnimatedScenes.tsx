import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { gsap } from 'gsap';

export default function AnimatedScenes() {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Scene setup
    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0x0a0a1f, 1, 50);

    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.set(0, 3, 8);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setClearColor(0x0a0a1f);
    renderer.shadowMap.enabled = true;
    containerRef.current.appendChild(renderer.domElement);

    // Lighting
    const moonLight = new THREE.DirectionalLight(0xb0c4de, 0.5);
    moonLight.position.set(5, 10, 5);
    moonLight.castShadow = true;
    scene.add(moonLight);

    const ambientLight = new THREE.AmbientLight(0x1a237e, 0.2);
    scene.add(ambientLight);

    // Stars
    const starGeometry = new THREE.BufferGeometry();
    const starMaterial = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.1,
    });

    const starVertices = [];
    for (let i = 0; i < 1000; i++) {
      const x = (Math.random() - 0.5) * 100;
      const y = Math.random() * 50;
      const z = (Math.random() - 0.5) * 100;
      starVertices.push(x, y, z);
    }
    starGeometry.setAttribute('position', new THREE.Float32BufferAttribute(starVertices, 3));
    const stars = new THREE.Points(starGeometry, starMaterial);
    scene.add(stars);

    // Moon
    const moonGeometry = new THREE.SphereGeometry(2, 32, 32);
    const moonMaterial = new THREE.MeshPhongMaterial({
      color: 0xffffff,
      emissive: 0xffffff,
      emissiveIntensity: 0.2,
    });
    const moon = new THREE.Mesh(moonGeometry, moonMaterial);
    moon.position.set(10, 15, -20);
    scene.add(moon);

    // Ground
    const groundGeometry = new THREE.PlaneGeometry(100, 100);
    const groundMaterial = new THREE.MeshPhongMaterial({
      color: 0x1a472a,
      shininess: 0,
    });
    const ground = new THREE.Mesh(groundGeometry, groundMaterial);
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    scene.add(ground);

    // Lake
    const lakeGeometry = new THREE.PlaneGeometry(20, 10);
    const lakeMaterial = new THREE.MeshPhongMaterial({
      color: 0x0d47a1,
      shininess: 100,
      specular: 0xffffff,
    });
    const lake = new THREE.Mesh(lakeGeometry, lakeMaterial);
    lake.rotation.x = -Math.PI / 2;
    lake.position.set(-10, 0.01, -5);
    scene.add(lake);

    // Wheat field with quaternion-based animation
    const createWheatStalk = () => {
      const stalkGeometry = new THREE.CylinderGeometry(0.02, 0.02, 1, 4);
      const stalkMaterial = new THREE.MeshPhongMaterial({ color: 0xd4af37 });
      const stalk = new THREE.Mesh(stalkGeometry, stalkMaterial);
      
      // Create a pivot point for animation
      const pivot = new THREE.Group();
      pivot.add(stalk);
      stalk.position.y = 0.5;
      
      // Store initial quaternion
      pivot.userData.initialRotation = new THREE.Quaternion().copy(pivot.quaternion);
      pivot.userData.targetRotation = new THREE.Quaternion();
      pivot.userData.currentRotation = new THREE.Quaternion();
      
      return pivot;
    };

    const wheatField = new THREE.Group();
    const wheatStalks = [];
    
    for (let i = 0; i < 1000; i++) {
      const stalk = createWheatStalk();
      stalk.position.x = (Math.random() - 0.5) * 50;
      stalk.position.z = (Math.random() - 0.5) * 50;
      
      if (new THREE.Vector3(stalk.position.x, 0, stalk.position.z).distanceTo(lake.position) > 12) {
        stalk.userData.randomOffset = Math.random() * Math.PI * 2;
        wheatField.add(stalk);
        wheatStalks.push(stalk);
      }
    }
    scene.add(wheatField);

    // Electricity poles
    const createPole = () => {
      const poleGroup = new THREE.Group();

      // Pole
      const poleGeometry = new THREE.CylinderGeometry(0.1, 0.1, 8);
      const poleMaterial = new THREE.MeshPhongMaterial({ color: 0x4d4d4d });
      const pole = new THREE.Mesh(poleGeometry, poleMaterial);
      pole.castShadow = true;
      poleGroup.add(pole);

      // Cross beam
      const beamGeometry = new THREE.BoxGeometry(2, 0.1, 0.1);
      const beam = new THREE.Mesh(beamGeometry, poleMaterial);
      beam.position.y = 3.5;
      poleGroup.add(beam);

      return poleGroup;
    };

    const poles = new THREE.Group();
    for (let i = -5; i <= 5; i++) {
      const pole = createPole();
      pole.position.set(i * 10, 4, 5);
      poles.add(pole);
    }
    scene.add(poles);

    // Car
    const car = new THREE.Group();

    // Car body
    const bodyGeometry = new THREE.BoxGeometry(2, 0.5, 1);
    const bodyMaterial = new THREE.MeshPhongMaterial({ color: 0xff5f1f });
    const body = new THREE.Mesh(bodyGeometry, bodyMaterial);
    body.castShadow = true;
    car.add(body);

    // Roof
    const roofGeometry = new THREE.BoxGeometry(1.2, 0.4, 0.9);
    const roof = new THREE.Mesh(roofGeometry, bodyMaterial);
    roof.position.y = 0.45;
    roof.position.x = -0.2;
    car.add(roof);

    // Wheels
    const wheelGeometry = new THREE.CylinderGeometry(0.2, 0.2, 0.1, 16);
    const wheelMaterial = new THREE.MeshPhongMaterial({ color: 0x1a1a1a });
    
    const wheels = [
      { x: -0.6, z: 0.6 },
      { x: 0.6, z: 0.6 },
      { x: -0.6, z: -0.6 },
      { x: 0.6, z: -0.6 },
    ].map(pos => {
      const wheel = new THREE.Mesh(wheelGeometry, wheelMaterial);
      wheel.rotation.z = Math.PI / 2;
      wheel.position.set(pos.x, -0.2, pos.z);
      return wheel;
    });
    wheels.forEach(wheel => car.add(wheel));

    // Headlights
    const headlightGeometry = new THREE.CircleGeometry(0.1, 16);
    const headlightMaterial = new THREE.MeshPhongMaterial({
      color: 0xffffff,
      emissive: 0xffffff,
      emissiveIntensity: 1,
    });

    const headlights = [
      { x: 1, z: 0.4 },
      { x: 1, z: -0.4 },
    ].map(pos => {
      const light = new THREE.Mesh(headlightGeometry, headlightMaterial);
      light.position.set(pos.x, 0, pos.z);
      light.rotation.y = Math.PI / 2;
      return light;
    });
    headlights.forEach(light => car.add(light));

    car.position.set(-20, 0.4, 3);
    scene.add(car);

    // Animations
    gsap.to(car.position, {
      x: 20,
      duration: 10,
      repeat: -1,
      ease: 'none',
    });

    // Handle window resize
    const handleResize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    // Animation loop with quaternion-based wheat animation
    const animate = () => {
      const animationId = requestAnimationFrame(animate);
      
      // Lake shimmer
      lakeMaterial.emissiveIntensity = 0.1 + Math.sin(Date.now() * 0.001) * 0.05;
      
      // Animate wheat stalks using quaternions
      const time = Date.now() * 0.001;
      wheatStalks.forEach((stalk) => {
        const offset = stalk.userData.randomOffset;
        const angle = Math.sin(time + offset) * 0.1;
        
        // Create rotation quaternion
        const rotationAxis = new THREE.Vector3(1, 0, 0);
        stalk.userData.targetRotation.setFromAxisAngle(rotationAxis, angle);
        
        // Smoothly interpolate between current and target rotation
        stalk.userData.currentRotation.slerp(stalk.userData.targetRotation, 0.1);
        stalk.quaternion.copy(stalk.userData.currentRotation);
      });
      
      renderer.render(scene, camera);

      if (!containerRef.current) {
        cancelAnimationFrame(animationId);
      }
    };

    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (containerRef.current && renderer.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
      // Clean up geometries and materials
      [
        starGeometry, starMaterial,
        moonGeometry, moonMaterial,
        groundGeometry, groundMaterial,
        lakeGeometry, lakeMaterial,
        ...wheatStalks.map(stalk => stalk.children[0].geometry),
        ...wheatStalks.map(stalk => stalk.children[0].material),
      ].forEach(item => item?.dispose?.());
    };
  }, []);

  return (
    <div ref={containerRef} className="absolute inset-0" />
  );
}
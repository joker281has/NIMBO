import React from 'react';
import { Star, ThumbsUp, Flag } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface Review {
  id: string;
  user: {
    name: string;
    avatar?: string;
  };
  rating: number;
  comment: string;
  createdAt: string;
  helpful: number;
}

interface ReviewListProps {
  reviews: Review[];
  onHelpful: (reviewId: string) => void;
  onReport: (reviewId: string) => void;
}

export default function ReviewList({ reviews, onHelpful, onReport }: ReviewListProps) {
  return (
    <div className="space-y-6">
      {reviews.map((review) => (
        <div key={review.id} className="bg-nimbo-dark rounded-lg p-4">
          <div className="flex items-start justify-between">
            <div className="flex items-center space-x-3">
              {review.user.avatar ? (
                <img
                  src={review.user.avatar}
                  alt={review.user.name}
                  className="w-10 h-10 rounded-full"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-nimbo-orange/20 flex items-center justify-center">
                  <span className="text-nimbo-orange font-semibold">
                    {review.user.name[0].toUpperCase()}
                  </span>
                </div>
              )}
              <div>
                <div className="font-medium">{review.user.name}</div>
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-4 h-4 ${
                        i < review.rating
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-400'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
            <span className="text-sm text-gray-400">
              {formatDistanceToNow(new Date(review.createdAt), { addSuffix: true })}
            </span>
          </div>

          <p className="mt-4 text-gray-300">{review.comment}</p>

          <div className="mt-4 flex items-center space-x-4">
            <button
              onClick={() => onHelpful(review.id)}
              className="flex items-center space-x-1 text-sm text-gray-400 hover:text-white transition-colors"
            >
              <ThumbsUp className="w-4 h-4" />
              <span>Helpful ({review.helpful})</span>
            </button>
            <button
              onClick={() => onReport(review.id)}
              className="flex items-center space-x-1 text-sm text-gray-400 hover:text-red-500 transition-colors"
            >
              <Flag className="w-4 h-4" />
              <span>Report</span>
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}
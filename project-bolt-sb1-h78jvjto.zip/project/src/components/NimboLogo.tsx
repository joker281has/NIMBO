import React from 'react';

interface NimboLogoProps {
  className?: string;
}

export default function NimboLogo({ className = '' }: NimboLogoProps) {
  return (
    <div className={`relative ${className}`}>
      <div className="w-12 h-12 rounded-full bg-nimbo-orange flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-nimbo-orange to-nimbo-orange-light opacity-80"></div>
        <div className="relative flex items-center">
          <span className="text-black font-bold text-xs mr-0.5">»</span>
          <span className="text-white font-bold text-xs tracking-wide">NIMBO</span>
        </div>
      </div>
    </div>
  );
}
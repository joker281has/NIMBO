import React, { useState } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { X, CreditCard, AppleIcon } from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  service: {
    name: string;
    price: number;
    description: string;
  };
}

// Use a proper Stripe test publishable key
const stripePromise = loadStripe('pk_test_51OqXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');

export default function PaymentModal({ isOpen, onClose, service }: PaymentModalProps) {
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleStripePayment = async () => {
    setLoading(true);
    try {
      const stripe = await stripePromise;
      if (!stripe) throw new Error('Stripe failed to load');

      // Here you would typically make an API call to your backend to create a payment intent
      // For demonstration purposes, we'll show a success message
      alert('This is a test mode. In production, this would process a real payment.');
    } catch (error) {
      console.error('Payment failed:', error);
      alert('Payment failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleApplePay = async () => {
    setLoading(true);
    try {
      const stripe = await stripePromise;
      if (!stripe) throw new Error('Stripe failed to load');

      // Check if Apple Pay is available
      const paymentRequest = stripe.paymentRequest({
        country: 'US',
        currency: 'usd',
        total: {
          label: service.name,
          amount: service.price * 100, // Amount in cents
        },
        requestPayerName: true,
        requestPayerEmail: true,
      });

      const canMakePayment = await paymentRequest.canMakePayment();

      if (!canMakePayment) {
        alert('Apple Pay is not available on this device');
        return;
      }

      // Here you would typically handle the Apple Pay flow
      alert('This is a test mode. In production, this would initiate Apple Pay.');
    } catch (error) {
      console.error('Apple Pay failed:', error);
      alert('Apple Pay failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="relative w-full max-w-md bg-nimbo-dark-lighter rounded-xl shadow-2xl p-6">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 hover:bg-nimbo-dark rounded-lg transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="mb-6">
          <h3 className="text-2xl font-bold mb-2">{service.name}</h3>
          <p className="text-gray-400">{service.description}</p>
          <div className="mt-4 text-2xl font-bold text-nimbo-orange">
            ${service.price.toFixed(2)}
          </div>
        </div>

        <div className="space-y-4">
          <button
            onClick={handleStripePayment}
            disabled={loading}
            className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-lg transition-colors disabled:opacity-50"
          >
            <CreditCard className="w-5 h-5" />
            <span>Pay with Card</span>
          </button>

          <button
            onClick={handleApplePay}
            disabled={loading}
            className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-black hover:bg-gray-900 rounded-lg transition-colors disabled:opacity-50"
          >
            <AppleIcon className="w-5 h-5" />
            <span>Pay with Apple Pay</span>
          </button>
        </div>

        <p className="mt-6 text-sm text-center text-gray-400">
          Secure payment powered by Stripe (Test Mode)
        </p>
      </div>
    </div>
  );
}
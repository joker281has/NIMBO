import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { gsap } from 'gsap';

export default function FloatingServer() {
  const containerRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;

  useEffect(() => {
    if (!containerRef.current || isMobile) return;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, 1, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ 
      antialias: true,
      alpha: true,
      powerPreference: "high-performance"
    });

    rendererRef.current = renderer;
    
    // Create solid sphere with Nimbo brand color (FF5F1F)
    const sphereGeometry = new THREE.SphereGeometry(1.5, 32, 32);
    const sphereMaterial = new THREE.MeshPhongMaterial({
      color: new THREE.Color('#FF5F1F'),
      shininess: 80,
      emissive: new THREE.Color('#FF5F1F'),
      emissiveIntensity: 0.2,
    });
    const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
    sphere.renderOrder = 2;
    scene.add(sphere);

    // Create simplified clouds for better performance
    const clouds: THREE.Mesh[] = [];
    const createCloud = (position: THREE.Vector3, scale: number = 1, direction: 1 | -1 = 1) => {
      const cloudGeometry = new THREE.SphereGeometry(0.6, 16, 16);
      const cloudMaterial = new THREE.MeshStandardMaterial({
        color: 0xFFFFFF,
        transparent: true,
        opacity: 0.95,
        roughness: 0.2,
        metalness: 0.1,
      });
      
      const cloud = new THREE.Mesh(cloudGeometry, cloudMaterial);
      cloud.position.copy(position);
      cloud.scale.set(scale, scale * 0.6, scale);
      cloud.renderOrder = 1;
      
      (cloud as any).direction = direction;
      (cloud as any).baseZ = position.z;

      // Reduced number of puffs for better performance
      const puffs = [
        { pos: new THREE.Vector3(0.4, 0, 0), scale: 0.8 },
        { pos: new THREE.Vector3(-0.4, 0, 0), scale: 0.8 }
      ];

      puffs.forEach(({ pos, scale: puffScale }) => {
        const puff = new THREE.Mesh(cloudGeometry, cloudMaterial);
        puff.position.copy(pos).multiplyScalar(scale);
        puff.scale.set(scale * puffScale, scale * puffScale * 0.6, scale * puffScale);
        cloud.add(puff);
      });

      scene.add(cloud);
      clouds.push(cloud);
      return cloud;
    };

    // Create fewer clouds for better performance
    [
      new THREE.Vector3(4, 1.5, -1.5),
      new THREE.Vector3(-4, -1.2, 1.5),
    ].forEach((pos, i) => createCloud(pos, 1.2, i === 0 ? -1 : 1));

    camera.position.z = 5;

    // Simplified lighting setup
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.0);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0xffffff, 1.2);
    pointLight.position.set(5, 5, 5);
    scene.add(pointLight);

    // Create text overlay with only one arrow
    const textOverlay = document.createElement('div');
    textOverlay.className = 'absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none';
    textOverlay.innerHTML = `
      <div class="relative flex items-center space-x-1">
        <span class="text-black font-bold text-2xl">&raquo;</span>
        <span class="text-white font-bold text-2xl tracking-wide">NIMBO</span>
      </div>
    `;
    containerRef.current.appendChild(textOverlay);

    // Responsive sizing
    const updateSize = () => {
      if (!containerRef.current) return;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;
      renderer.setSize(width, height);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
    };

    updateSize();
    window.addEventListener('resize', updateSize);
    containerRef.current.appendChild(renderer.domElement);

    // Optimized animation
    let time = 0;
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      
      time += 0.01;
      
      // Simplified rotation
      sphere.rotation.y = time * 0.2;
      sphere.position.y = Math.sin(time * 0.5) * 0.1;

      // Optimized cloud movement
      clouds.forEach((cloud) => {
        const direction = (cloud as any).direction;
        cloud.position.x += 0.008 * direction;
        
        if (direction > 0 && cloud.position.x > 4) {
          cloud.position.x = -4;
        } else if (direction < 0 && cloud.position.x < -4) {
          cloud.position.x = 4;
        }
      });
      
      renderer.render(scene, camera);
    };

    animate();

    // Cleanup
    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', updateSize);
      if (containerRef.current) {
        if (textOverlay.parentNode === containerRef.current) {
          containerRef.current.removeChild(textOverlay);
        }
        if (renderer.domElement.parentNode === containerRef.current) {
          containerRef.current.removeChild(renderer.domElement);
        }
      }
      sphereGeometry.dispose();
      sphereMaterial.dispose();
      clouds.forEach(cloud => {
        cloud.geometry.dispose();
        (cloud.material as THREE.Material).dispose();
      });
      renderer.dispose();
    };
  }, [isMobile]);

  // Enhanced mobile fallback with better performance
  if (isMobile) {
    return (
      <div className="relative w-full py-8 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-nimbo-dark via-nimbo-dark to-transparent opacity-30"></div>
        <div className="relative flex justify-center items-center">
          <div className="relative w-16 h-16">
            {/* Optimized animated rings */}
            <div className="absolute inset-0 rounded-full border-2 border-nimbo-orange opacity-20 animate-[ping_4s_cubic-bezier(0,0,0.2,1)_infinite]"></div>
            <div className="absolute inset-0 rounded-full border border-nimbo-orange/30 animate-[pulse_2s_cubic-bezier(0.4,0,0.6,1)_infinite]"></div>
            {/* Main circle with improved gradient */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-nimbo-orange via-nimbo-orange to-nimbo-orange-light opacity-90"></div>
            {/* Logo with better positioning and only one arrow */}
            <div className="absolute inset-0 flex items-center justify-center space-x-1">
              <span className="text-black font-bold text-xl">&raquo;</span>
              <span className="text-white font-bold text-xl">NIMBO</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      ref={containerRef} 
      className="absolute right-10 top-1/2 -translate-y-1/2 w-[300px] h-[300px] cursor-pointer"
    />
  );
}
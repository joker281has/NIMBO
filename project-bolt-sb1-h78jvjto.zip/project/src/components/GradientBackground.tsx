import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

export default function GradientBackground() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isMobile = typeof window !== 'undefined' && window.innerWidth < 768;

  useEffect(() => {
    if (!containerRef.current) return;

    // Optimized animations for better performance
    const tl = gsap.timeline({ repeat: -1 });

    if (isMobile) {
      // Simplified animation for mobile
      tl.to('.gradient-overlay', {
        backgroundPosition: '200% 200%',
        duration: 20,
        ease: 'none'
      });
    } else {
      // Full animation for desktop
      tl.to('.gradient-overlay', {
        backgroundPosition: '200% 200%',
        duration: 15,
        ease: 'none'
      });

      gsap.to('.light-flare', {
        opacity: 0.6,
        scale: 1.2,
        duration: 2,
        repeat: -1,
        yoyo: true,
        stagger: {
          each: 0.5,
          from: "random"
        }
      });
    }

    return () => {
      tl.kill();
      gsap.killTweensOf('.light-flare');
    };
  }, [isMobile]);

  return (
    <div ref={containerRef} className="absolute inset-0 overflow-hidden">
      {/* Optimized hexagonal grid pattern */}
      <div className="absolute inset-0 opacity-[0.03]">
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 0l25.98 15v30L30 60 4.02 45V15L30 0z' stroke-width='1' stroke='%23FF5F1F' fill='none' fill-rule='evenodd'/%3E%3C/svg%3E")`,
          backgroundSize: isMobile ? '24px 24px' : '60px 60px',
          backgroundPosition: 'center'
        }}></div>
      </div>
      
      {/* Optimized gradient background */}
      <div className="gradient-overlay absolute inset-0 bg-gradient-to-br from-[#0A0A0F] via-[#12121A] to-nimbo-orange/5 bg-[length:400%_400%] opacity-95"></div>
      
      {/* Light flares only on desktop with reduced opacity */}
      {!isMobile && (
        <div className="absolute inset-0 pointer-events-none">
          <div
            className="light-flare absolute w-96 h-96 rounded-full bg-nimbo-orange/3 blur-3xl"
            style={{
              left: '25%',
              top: '30%',
              transform: 'translate(-50%, -50%)'
            }}
          />
        </div>
      )}
    </div>
  );
}
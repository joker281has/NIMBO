import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Loader2, Bot, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

interface Message {
  id: string;
  type: 'user' | 'bot';
  content: string;
  timestamp: Date;
}

const INITIAL_MESSAGE: Message = {
  id: '1',
  type: 'bot',
  content: "Hi! I'm Nimbo Assistant. How can I help you today?",
  timestamp: new Date()
};

const QUICK_SUGGESTIONS = [
  'Tell me about your AI services',
  'How does cloud infrastructure work?',
  'What security features do you offer?',
  'I need help with pricing'
];

const FALLBACK_RESPONSES: { [key: string]: string } = {
  'ai services': `Our AI & Machine Learning services include:
• Custom ML models trained on your data
• Natural Language Processing
• Predictive analytics and forecasting
• AI-powered automation solutions
• Real-time data analysis

Starting from $499/month. Would you like to schedule a consultation to discuss your specific AI needs?`,

  'cloud infrastructure': `Our cloud infrastructure provides:
• Global network of data centers
• Auto-scaling capabilities
• 99.99% uptime guarantee
• Advanced monitoring and analytics
• Pay-as-you-go pricing model
• Enterprise-grade security

Starting from $299/month. Would you like to schedule a consultation with our cloud experts?`,

  'security': `Our comprehensive security solutions include:
• Advanced threat detection
• End-to-end encryption
• Multi-factor authentication
• Regular security audits
• Compliance management
• 24/7 security monitoring
• Incident response team

Starting from $599/month. Let's schedule a consultation to discuss your security requirements.`,

  'pricing': `Our flexible pricing is tailored to your needs:

• AI & ML Services: From $499/month
• Cloud Infrastructure: From $299/month
• Security Solutions: From $599/month
• Enterprise Solutions: Custom pricing

Book a consultation for a detailed quote based on your requirements.`,

  'support': `We offer comprehensive support:
• 24/7 technical assistance
• Dedicated support team
• Priority incident response
• Regular system health checks
• Performance optimization
• Security monitoring

Contact our support team or schedule a consultation for more details.`,

  'default': `I can help you with:
• AI & Machine Learning solutions
• Cloud infrastructure
• Security features
• Pricing information
• Technical support
• Consultation booking

What would you like to know more about?`
};

const getFallbackResponse = (message: string): string => {
  const lowercaseMessage = message.toLowerCase();
  
  if (lowercaseMessage.includes('ai') || lowercaseMessage.includes('machine learning')) {
    return FALLBACK_RESPONSES['ai services'];
  }
  if (lowercaseMessage.includes('cloud') || lowercaseMessage.includes('infrastructure')) {
    return FALLBACK_RESPONSES['cloud infrastructure'];
  }
  if (lowercaseMessage.includes('security') || lowercaseMessage.includes('protect')) {
    return FALLBACK_RESPONSES['security'];
  }
  if (lowercaseMessage.includes('price') || lowercaseMessage.includes('cost')) {
    return FALLBACK_RESPONSES['pricing'];
  }
  if (lowercaseMessage.includes('support') || lowercaseMessage.includes('help')) {
    return FALLBACK_RESPONSES['support'];
  }
  
  return FALLBACK_RESPONSES['default'];
};

export default function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([INITIAL_MESSAGE]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  const handleSend = async () => {
    if (!inputValue.trim() || isTyping) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: inputValue.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    try {
      const response = getFallbackResponse(userMessage.content);
      
      // Add a small delay to simulate processing
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const botMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'bot',
        content: response,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleQuickSuggestion = (suggestion: string) => {
    setInputValue(suggestion);
    handleSend();
  };

  return (
    <>
      {/* Chat Button */}
      <button
        onClick={() => setIsOpen(true)}
        className={`fixed bottom-6 right-6 w-14 h-14 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-full shadow-lg flex items-center justify-center transition-all duration-200 hover:scale-110 ${
          isOpen ? 'scale-0 opacity-0' : 'scale-100 opacity-100'
        }`}
        aria-label="Open chat"
      >
        <MessageSquare className="w-6 h-6 text-white" />
      </button>

      {/* Chat Window */}
      <div
        className={`fixed bottom-6 right-6 w-96 max-w-[calc(100vw-3rem)] bg-nimbo-dark-lighter rounded-lg shadow-xl border border-nimbo-dark overflow-hidden transition-all duration-300 transform ${
          isOpen ? 'scale-100 opacity-100' : 'scale-95 opacity-0 pointer-events-none'
        }`}
      >
        {/* Header */}
        <div className="bg-nimbo-dark p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-nimbo-orange/20 flex items-center justify-center">
              <Bot className="w-5 h-5 text-nimbo-orange" />
            </div>
            <div>
              <h3 className="font-semibold">Nimbo Assistant</h3>
              <p className="text-xs text-gray-400">AI-Powered Support</p>
            </div>
          </div>
          <button
            onClick={() => setIsOpen(false)}
            className="p-2 hover:bg-nimbo-dark-light rounded-lg transition-colors"
            aria-label="Close chat"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Messages */}
        <div className="h-96 overflow-y-auto p-4 space-y-4">
          {messages.map(message => (
            <div
              key={message.id}
              className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.type === 'user'
                    ? 'bg-nimbo-orange text-white'
                    : 'bg-nimbo-dark text-white'
                }`}
              >
                <p className="text-sm whitespace-pre-line">{message.content}</p>
                <span className="text-xs opacity-75 mt-1 block">
                  {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start">
              <div className="bg-nimbo-dark rounded-lg p-3">
                <Loader2 className="w-5 h-5 animate-spin" />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestions */}
        {messages.length === 1 && (
          <div className="p-4 grid grid-cols-2 gap-2">
            {QUICK_SUGGESTIONS.map((suggestion, index) => (
              <button
                key={index}
                onClick={() => handleQuickSuggestion(suggestion)}
                className="text-sm p-2 bg-nimbo-dark hover:bg-nimbo-dark-light rounded-lg text-left transition-colors"
              >
                {suggestion}
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <div className="p-4 border-t border-nimbo-dark">
          <div className="relative">
            <textarea
              ref={inputRef}
              value={inputValue}
              onChange={e => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="w-full pr-12 py-2 px-4 bg-nimbo-dark border border-nimbo-dark-lighter rounded-lg focus:outline-none focus:ring-2 focus:ring-nimbo-orange/50 resize-none"
              rows={1}
            />
            <button
              onClick={handleSend}
              disabled={!inputValue.trim() || isTyping}
              className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-gray-400 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          <div className="mt-2 text-center">
            <Link
              to="/consultation"
              className="inline-flex items-center text-sm text-nimbo-orange hover:text-nimbo-orange-light"
            >
              Book a consultation for detailed assistance
              <ExternalLink className="w-4 h-4 ml-1" />
            </Link>
          </div>
        </div>
      </div>
    </>
  );
}
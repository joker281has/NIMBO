import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { gsap } from 'gsap';

export default function CloudIntro({ onAnimationComplete }: { onAnimationComplete: () => void }) {
  const containerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!containerRef.current) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance"
    });

    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.5;
    containerRef.current.appendChild(renderer.domElement);

    // Enhanced volumetric cloud shader with improved lighting
    const cloudMaterial = new THREE.ShaderMaterial({
      uniforms: {
        time: { value: 0 },
        resolution: { value: new THREE.Vector2(window.innerWidth, window.innerHeight) },
        cameraPos: { value: new THREE.Vector3() },
        cameraDir: { value: new THREE.Vector3() },
        lightDir: { value: new THREE.Vector3(0.5, 1.0, 0.2).normalize() },
        cloudScale: { value: 0.8 }, // Adjusted for better detail
        densityFactor: { value: 1.2 }, // Increased for more visible clouds
        noiseScale: { value: new THREE.Vector3(0.3, 0.2, 0.2) },
        noiseOffset: { value: new THREE.Vector3() },
        splitPoint: { value: 0.5 }, // For parting animation
        splitWidth: { value: 0.0 }, // Controls the gap between cloud parts
        sunColor: { value: new THREE.Vector3(1.0, 0.9, 0.8) }, // Warm sunlight color
        ambientColor: { value: new THREE.Vector3(0.6, 0.7, 1.0) } // Blue sky color
      },
      vertexShader: `
        varying vec2 vUv;
        void main() {
          vUv = uv;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec2 vUv;
        uniform float time;
        uniform vec2 resolution;
        uniform vec3 cameraPos;
        uniform vec3 cameraDir;
        uniform vec3 lightDir;
        uniform float cloudScale;
        uniform float densityFactor;
        uniform vec3 noiseScale;
        uniform vec3 noiseOffset;
        uniform float splitPoint;
        uniform float splitWidth;
        uniform vec3 sunColor;
        uniform vec3 ambientColor;

        #define STEPS 128
        #define STEP_SIZE 0.05
        #define LIGHT_STEPS 8
        #define LIGHT_STEP_SIZE 0.1

        // Enhanced noise function with better turbulence
        vec3 hash33(vec3 p) {
          p = vec3(dot(p,vec3(127.1,311.7,74.7)),
                   dot(p,vec3(269.5,183.3,246.1)),
                   dot(p,vec3(113.5,271.9,124.6)));
          return -1.0 + 2.0 * fract(sin(p)*43758.5453123);
        }

        float noise(vec3 p) {
          vec3 i = floor(p);
          vec3 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          
          return mix(
            mix(mix(dot(hash33(i + vec3(0,0,0)), f - vec3(0,0,0)),
                   dot(hash33(i + vec3(1,0,0)), f - vec3(1,0,0)), f.x),
                mix(dot(hash33(i + vec3(0,1,0)), f - vec3(0,1,0)),
                    dot(hash33(i + vec3(1,1,0)), f - vec3(1,1,0)), f.x), f.y),
            mix(mix(dot(hash33(i + vec3(0,0,1)), f - vec3(0,0,1)),
                   dot(hash33(i + vec3(1,0,1)), f - vec3(1,0,1)), f.x),
                mix(dot(hash33(i + vec3(0,1,1)), f - vec3(0,1,1)),
                    dot(hash33(i + vec3(1,1,1)), f - vec3(1,1,1)), f.x), f.y), f.z);
        }

        // Enhanced FBM with more octaves for detail
        float fbm(vec3 p) {
          float f = 0.0;
          float amp = 0.5;
          float freq = 1.0;
          for(int i = 0; i < 6; i++) {
            f += amp * noise(p * freq);
            freq *= 2.0;
            amp *= 0.5;
          }
          return f;
        }

        // Improved cloud shape function
        float cloudShape(vec3 p) {
          float base = fbm(p * cloudScale + vec3(time * 0.1));
          float detail = fbm(p * cloudScale * 3.0 + vec3(time * 0.2));
          float detail2 = fbm(p * cloudScale * 9.0 + vec3(time * 0.3));
          
          float shape = base;
          shape += detail * 0.5;
          shape += detail2 * 0.25;
          
          return shape;
        }

        float sampleDensity(vec3 p) {
          p = p * noiseScale + noiseOffset;
          
          // Split animation
          float split = smoothstep(splitPoint - splitWidth, splitPoint + splitWidth, p.x);
          if (abs(p.x - splitPoint) < splitWidth) return 0.0;
          
          float shape = cloudShape(p);
          float density = smoothstep(0.1, 0.6, shape);
          
          // Enhanced cloud shape
          density *= smoothstep(1.0, 0.7, length(p.xz) * 0.25);
          density *= smoothstep(1.0, 0.0, abs(p.y) * 0.5);
          
          // Apply split effect
          density *= (p.x < splitPoint) ? (1.0 - split) : split;
          
          return density * densityFactor;
        }

        vec4 raymarch(vec3 ro, vec3 rd) {
          vec4 acc = vec4(0.0);
          float t = 0.0;
          
          for(int i = 0; i < STEPS; i++) {
            if(acc.a >= 0.99) break;
            
            vec3 pos = ro + rd * t;
            float density = sampleDensity(pos);
            
            if(density > 0.01) {
              float lightDensity = 0.0;
              vec3 lightPos = pos;
              
              for(int j = 0; j < LIGHT_STEPS; j++) {
                lightPos += lightDir * LIGHT_STEP_SIZE;
                lightDensity += sampleDensity(lightPos) * 0.1;
              }
              
              // Enhanced lighting with sun and ambient colors
              vec3 color = mix(sunColor, ambientColor, lightDensity);
              float alpha = density * STEP_SIZE;
              
              // Add silver lining effect
              float rimLight = pow(1.0 - abs(dot(rd, lightDir)), 4.0);
              color += sunColor * rimLight * 0.5;
              
              acc += vec4(color * alpha * (1.0 - acc.a), alpha);
            }
            
            t += STEP_SIZE;
          }
          
          return acc;
        }

        void main() {
          vec2 uv = (gl_FragCoord.xy / resolution.xy) * 2.0 - 1.0;
          uv.x *= resolution.x / resolution.y;
          
          vec3 rd = normalize(vec3(uv, -1.5));
          vec3 ro = cameraPos;
          
          vec4 cloud = raymarch(ro, rd);
          
          // Add atmospheric scattering effect
          vec3 atmosphere = mix(ambientColor, sunColor, pow(max(dot(rd, lightDir), 0.0), 32.0));
          cloud.rgb += atmosphere * (1.0 - cloud.a) * 0.2;
          
          gl_FragColor = vec4(cloud.rgb, cloud.a);
        }
      `,
      transparent: true,
    });

    // Create a full-screen quad
    const geometry = new THREE.PlaneGeometry(2, 2);
    const mesh = new THREE.Mesh(geometry, cloudMaterial);
    scene.add(mesh);

    camera.position.z = 5;

    // Animation variables
    let time = 0;
    const noiseOffset = new THREE.Vector3();

    // Enhanced animation timeline
    const tl = gsap.timeline({
      onComplete: () => {
        // Final fade out with light burst
        const burst = document.createElement('div');
        burst.className = 'absolute inset-0 bg-white';
        burst.style.opacity = '0';
        containerRef.current?.appendChild(burst);

        gsap.to(burst, {
          opacity: 0.8,
          duration: 0.5,
          ease: 'power2.in',
          onComplete: () => {
            gsap.to(burst, {
              opacity: 0,
              duration: 1,
              ease: 'power2.out',
              onComplete: () => {
                if (containerRef.current) {
                  containerRef.current.style.display = 'none';
                }
                onAnimationComplete();
              }
            });
          }
        });
      }
    });

    // Initial cloud formation
    tl.fromTo(cloudMaterial.uniforms.densityFactor, {
      value: 0
    }, {
      value: 1.2,
      duration: 2,
      ease: 'power2.inOut'
    });

    // Cloud movement and split
    tl.to(noiseOffset, {
      x: 2,
      y: 1,
      z: 1,
      duration: 3,
      ease: 'power2.inOut'
    });

    // Camera movement
    tl.to(camera.position, {
      x: 2,
      y: 1,
      duration: 2,
      ease: 'power2.inOut'
    }, '-=2');

    // Cloud parting animation
    tl.to(cloudMaterial.uniforms.splitWidth, {
      value: 0.3,
      duration: 2,
      ease: 'power2.inOut'
    }, '-=1');

    // Animation loop
    const animate = () => {
      const animationId = requestAnimationFrame(animate);
      time += 0.005;

      cloudMaterial.uniforms.time.value = time;
      cloudMaterial.uniforms.cameraPos.value.copy(camera.position);
      camera.getWorldDirection(cloudMaterial.uniforms.cameraDir.value);
      cloudMaterial.uniforms.noiseOffset.value.copy(noiseOffset);

      renderer.render(scene, camera);

      if (!containerRef.current) {
        cancelAnimationFrame(animationId);
      }
    };

    animate();

    // Handle window resize
    const handleResize = () => {
      const width = window.innerWidth;
      const height = window.innerHeight;
      
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
      cloudMaterial.uniforms.resolution.value.set(width, height);
    };

    window.addEventListener('resize', handleResize);
    handleResize();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (containerRef.current && renderer.domElement) {
        containerRef.current.removeChild(renderer.domElement);
      }
      geometry.dispose();
      cloudMaterial.dispose();
      renderer.dispose();
    };
  }, [onAnimationComplete]);

  return (
    <div 
      ref={containerRef} 
      className="fixed inset-0 z-50 bg-gradient-to-b from-[#0A0A0F] via-[#1E90FF] to-[#87CEEB]"
    />
  );
}
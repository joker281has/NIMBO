import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { useStore } from '../lib/store';

interface AddToCartButtonProps {
  item: {
    id: string;
    name: string;
    price: number;
  };
  variant?: 'primary' | 'secondary';
}

export default function AddToCartButton({ item, variant = 'primary' }: AddToCartButtonProps) {
  const { addToCart } = useStore();

  const handleClick = () => {
    addToCart(item);
  };

  return (
    <button
      onClick={handleClick}
      className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
        variant === 'primary'
          ? 'bg-nimbo-orange hover:bg-nimbo-orange-light'
          : 'bg-nimbo-dark hover:bg-nimbo-dark-light'
      }`}
    >
      <ShoppingCart className="w-5 h-5" />
      <span>Add to Cart</span>
    </button>
  );
}
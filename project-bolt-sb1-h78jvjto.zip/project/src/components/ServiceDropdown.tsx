import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronDown, Cpu, Cloud, Shield, Code, LineChart, Briefcase, Rocket, Headphones } from 'lucide-react';
import type { ServiceItem } from '../types/services';

interface DropdownProps {
  title: string;
  items: ServiceItem[];
}

const iconMap: { [key: string]: React.ReactNode } = {
  'AI & Machine Learning': <Cpu className="w-6 h-6 text-nimbo-orange" />,
  'Cloud Infrastructure': <Cloud className="w-6 h-6 text-nimbo-orange" />,
  'Cybersecurity': <Shield className="w-6 h-6 text-nimbo-orange" />,
  'Software Development': <Code className="w-6 h-6 text-nimbo-orange" />,
  'Business Intelligence': <LineChart className="w-6 h-6 text-nimbo-orange" />,
  'Enterprise Solutions': <Briefcase className="w-6 h-6 text-nimbo-orange" />,
  'Digital Transformation': <Rocket className="w-6 h-6 text-nimbo-orange" />,
  '24/7 Support': <Headphones className="w-6 h-6 text-nimbo-orange" />
};

export default function ServiceDropdown({ title, items }: DropdownProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div 
      className="relative" 
      onMouseEnter={() => setIsOpen(true)} 
      onMouseLeave={() => setIsOpen(false)}
    >
      <button 
        className="flex items-center space-x-1 hover:text-nimbo-orange transition-colors py-2"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span>{title}</span>
        <ChevronDown className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute left-0 mt-2 w-[480px] bg-nimbo-dark-lighter border border-nimbo-dark rounded-lg shadow-xl z-50">
          <div className="grid grid-cols-1 gap-2 p-4">
            {items.map((item, index) => (
              <Link
                key={index}
                to={item.path}
                className="flex items-start space-x-4 p-3 rounded-lg hover:bg-nimbo-dark transition-colors group"
              >
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-nimbo-dark flex items-center justify-center group-hover:bg-nimbo-orange/10">
                  {iconMap[item.name] || <Code className="w-6 h-6 text-nimbo-orange" />}
                </div>
                <div>
                  <h3 className="font-medium group-hover:text-nimbo-orange">{item.name}</h3>
                  <p className="text-sm text-gray-400">{item.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
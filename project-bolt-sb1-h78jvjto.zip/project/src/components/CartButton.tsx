import React, { useState } from 'react';
import { ShoppingCart } from 'lucide-react';
import { useStore } from '../lib/store';
import ShoppingCartModal from './ShoppingCart';

export default function CartButton() {
  const [isOpen, setIsOpen] = useState(false);
  const { cart } = useStore();

  const itemCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="relative p-2 hover:bg-nimbo-dark-lighter rounded-lg transition-colors"
      >
        <ShoppingCart className="w-6 h-6" />
        {itemCount > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center text-xs bg-nimbo-orange rounded-full">
            {itemCount}
          </span>
        )}
      </button>

      <ShoppingCartModal isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </>
  );
}
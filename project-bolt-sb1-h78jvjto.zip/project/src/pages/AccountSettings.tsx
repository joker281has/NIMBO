import React, { useState, useEffect } from 'react';
import { User, Lock, Bell, Globe, CreditCard, Mail, Phone } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useStore } from '../lib/store';
import LoadingSpinner from '../components/LoadingSpinner';
import SEO from '../components/SEO';

interface Profile {
  full_name: string;
  avatar_url: string | null;
  phone: string | null;
  email_notifications: boolean;
  sms_notifications: boolean;
  currency: string;
  language: string;
}

export default function AccountSettings() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const { preferences, updatePreferences } = useStore();

  useEffect(() => {
    loadProfile();
  }, []);

  async function loadProfile() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      setProfile(data);
    } catch (err) {
      setError('Failed to load profile');
      console.error('Error loading profile:', err);
    } finally {
      setLoading(false);
    }
  }

  async function updateProfile(updates: Partial<Profile>) {
    setSaving(true);
    setError(null);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const { error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id);

      if (error) throw error;
      setProfile(prev => prev ? { ...prev, ...updates } : null);
    } catch (err) {
      setError('Failed to update profile');
      console.error('Error updating profile:', err);
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return <LoadingSpinner fullScreen />;
  }

  return (
    <div className="min-h-screen bg-nimbo-dark p-8">
      <SEO 
        title="Account Settings"
        description="Manage your account settings and preferences"
      />

      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Account Settings</h1>

        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/50 rounded-lg text-red-500">
            {error}
          </div>
        )}

        <div className="space-y-6">
          {/* Profile Section */}
          <section className="bg-nimbo-dark-lighter rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center">
              <User className="w-5 h-5 mr-2" />
              Profile Information
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  value={profile?.full_name || ''}
                  onChange={(e) => updateProfile({ full_name: e.target.value })}
                  className="w-full px-4 py-2 bg-nimbo-dark border border-nimbo-dark-lighter rounded-md focus:outline-none focus:ring-2 focus:ring-nimbo-orange/50"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Phone Number
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="tel"
                    value={profile?.phone || ''}
                    onChange={(e) => updateProfile({ phone: e.target.value })}
                    className="w-full pl-10 pr-4 py-2 bg-nimbo-dark border border-nimbo-dark-lighter rounded-md focus:outline-none focus:ring-2 focus:ring-nimbo-orange/50"
                  />
                </div>
              </div>
            </div>
          </section>

          {/* Notifications Section */}
          <section className="bg-nimbo-dark-lighter rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center">
              <Bell className="w-5 h-5 mr-2" />
              Notifications
            </h2>

            <div className="space-y-4">
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={profile?.email_notifications}
                  onChange={(e) => updateProfile({ email_notifications: e.target.checked })}
                  className="rounded border-gray-300 text-nimbo-orange focus:ring-nimbo-orange"
                />
                <span>Email Notifications</span>
              </label>

              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={profile?.sms_notifications}
                  onChange={(e) => updateProfile({ sms_notifications: e.target.checked })}
                  className="rounded border-gray-300 text-nimbo-orange focus:ring-nimbo-orange"
                />
                <span>SMS Notifications</span>
              </label>
            </div>
          </section>

          {/* Preferences Section */}
          <section className="bg-nimbo-dark-lighter rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center">
              <Globe className="w-5 h-5 mr-2" />
              Preferences
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Currency
                </label>
                <select
                  value={preferences.currency}
                  onChange={(e) => updatePreferences({ currency: e.target.value })}
                  className="w-full px-4 py-2 bg-nimbo-dark border border-nimbo-dark-lighter rounded-md focus:outline-none focus:ring-2 focus:ring-nimbo-orange/50"
                >
                  <option value="USD">USD - US Dollar</option>
                  <option value="EUR">EUR - Euro</option>
                  <option value="GBP">GBP - British Pound</option>
                  <option value="JPY">JPY - Japanese Yen</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-300 mb-1">
                  Language
                </label>
                <select
                  value={profile?.language}
                  onChange={(e) => updateProfile({ language: e.target.value })}
                  className="w-full px-4 py-2 bg-nimbo-dark border border-nimbo-dark-lighter rounded-md focus:outline-none focus:ring-2 focus:ring-nimbo-orange/50"
                >
                  <option value="en">English</option>
                  <option value="es">Español</option>
                  <option value="fr">Français</option>
                  <option value="de">Deutsch</option>
                </select>
              </div>
            </div>
          </section>

          {/* Security Section */}
          <section className="bg-nimbo-dark-lighter rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center">
              <Lock className="w-5 h-5 mr-2" />
              Security
            </h2>

            <div className="space-y-4">
              <button
                onClick={() => {/* Handle password change */}}
                className="w-full px-4 py-2 bg-nimbo-dark hover:bg-nimbo-dark-light rounded-lg transition-colors text-left"
              >
                Change Password
              </button>

              <button
                onClick={() => {/* Handle 2FA setup */}}
                className="w-full px-4 py-2 bg-nimbo-dark hover:bg-nimbo-dark-light rounded-lg transition-colors text-left"
              >
                Set Up Two-Factor Authentication
              </button>
            </div>
          </section>

          {/* Payment Methods Section */}
          <section className="bg-nimbo-dark-lighter rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-6 flex items-center">
              <CreditCard className="w-5 h-5 mr-2" />
              Payment Methods
            </h2>

            <button
              onClick={() => {/* Handle adding payment method */}}
              className="px-4 py-2 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-lg transition-colors"
            >
              Add Payment Method
            </button>
          </section>
        </div>

        <div className="mt-8 flex justify-end">
          <button
            onClick={() => {/* Handle save all changes */}}
            disabled={saving}
            className="px-6 py-2 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-lg transition-colors disabled:opacity-50"
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </div>
      </div>
    </div>
  );
}
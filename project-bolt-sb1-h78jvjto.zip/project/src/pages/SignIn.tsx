import React from 'react';
import { Link } from 'react-router-dom';
import AuthForm from '../components/AuthForm';
import GradientBackground from '../components/GradientBackground';

export default function SignIn() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative px-4">
      <GradientBackground />
      
      <div className="relative z-10 w-full max-w-md">
        <AuthForm mode="signin" />
        
        <p className="mt-6 text-center text-gray-400">
          Don't have an account?{' '}
          <Link to="/signup" className="text-nimbo-orange hover:text-nimbo-orange-light">
            Sign up
          </Link>
        </p>
      </div>
    </div>
  );
}
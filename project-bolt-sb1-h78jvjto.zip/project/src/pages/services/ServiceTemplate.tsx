import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, Check, Star } from 'lucide-react';
import GradientBackground from '../../components/GradientBackground';

interface Testimonial {
  name: string;
  role: string;
  company: string;
  content: string;
  image: string;
}

interface PricingTier {
  name: string;
  price: string;
  description: string;
  features: string[];
  highlighted?: boolean;
}

interface Feature {
  title: string;
  description: string;
  icon: React.ReactNode;
}

interface ServiceTemplateProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  features?: Feature[];
  benefits?: string[];
  pricing?: PricingTier[];
  testimonials?: Testimonial[];
}

export default function ServiceTemplate({ 
  title, 
  description, 
  icon,
  features = [],
  benefits = [],
  pricing = [],
  testimonials = []
}: ServiceTemplateProps) {
  return (
    <div className="min-h-screen relative">
      <GradientBackground />
      
      <div className="relative container mx-auto px-4 py-20">
        <Link 
          to="/" 
          className="inline-flex items-center space-x-2 text-gray-400 hover:text-white mb-8 group"
        >
          <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Home</span>
        </Link>

        {/* Hero Section */}
        <div className="max-w-4xl mb-20">
          <div className="flex items-center space-x-4 mb-6">
            <div className="w-16 h-16 rounded-2xl bg-nimbo-dark-lighter flex items-center justify-center">
              {icon}
            </div>
            <h1 className="text-4xl font-bold">{title}</h1>
          </div>
          
          <p className="text-xl text-gray-400 mb-8">{description}</p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              to="/consultation"
              className="px-6 py-3 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-lg transition-colors text-center"
            >
              Book a Consultation
            </Link>
            <Link
              to="/docs"
              className="px-6 py-3 bg-nimbo-dark-lighter hover:bg-nimbo-dark-light rounded-lg transition-colors text-center"
            >
              View Documentation
            </Link>
          </div>
        </div>

        {/* Features Section */}
        {features.length > 0 && (
          <section className="mb-20">
            <h2 className="text-3xl font-bold mb-12">Key Features</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <div 
                  key={index}
                  className="bg-nimbo-dark-lighter rounded-lg p-6 hover:bg-nimbo-dark-light transition-colors"
                >
                  <div className="w-12 h-12 rounded-lg bg-nimbo-dark flex items-center justify-center mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-400">{feature.description}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Benefits Section */}
        {benefits.length > 0 && (
          <section className="mb-20">
            <h2 className="text-3xl font-bold mb-12">Benefits</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {benefits.map((benefit, index) => (
                <div 
                  key={index}
                  className="flex items-start space-x-3"
                >
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-nimbo-orange/20 flex items-center justify-center">
                    <Check className="w-4 h-4 text-nimbo-orange" />
                  </div>
                  <p className="text-gray-300">{benefit}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Pricing Section */}
        {pricing.length > 0 && (
          <section className="mb-20">
            <h2 className="text-3xl font-bold mb-12">Pricing Plans</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {pricing.map((tier, index) => (
                <div 
                  key={index}
                  className={`relative rounded-lg p-8 ${
                    tier.highlighted 
                      ? 'bg-nimbo-orange/10 border-2 border-nimbo-orange' 
                      : 'bg-nimbo-dark-lighter'
                  }`}
                >
                  {tier.highlighted && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-nimbo-orange rounded-full text-sm font-semibold">
                      Most Popular
                    </div>
                  )}
                  <h3 className="text-2xl font-bold mb-2">{tier.name}</h3>
                  <div className="mb-4">
                    <span className="text-4xl font-bold">{tier.price}</span>
                    {tier.price !== 'Custom' && <span className="text-gray-400">/month</span>}
                  </div>
                  <p className="text-gray-400 mb-6">{tier.description}</p>
                  <ul className="space-y-4 mb-8">
                    {tier.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-start space-x-3">
                        <Check className="w-5 h-5 text-nimbo-orange flex-shrink-0" />
                        <span className="text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Link
                    to="/consultation"
                    className={`block text-center px-6 py-3 rounded-lg transition-colors ${
                      tier.highlighted
                        ? 'bg-nimbo-orange hover:bg-nimbo-orange-light'
                        : 'bg-nimbo-dark hover:bg-nimbo-dark-light'
                    }`}
                  >
                    Get Started
                  </Link>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Testimonials Section */}
        {testimonials.length > 0 && (
          <section className="mb-20">
            <h2 className="text-3xl font-bold mb-12">What Our Clients Say</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {testimonials.map((testimonial, index) => (
                <div 
                  key={index}
                  className="bg-nimbo-dark-lighter rounded-lg p-6"
                >
                  <div className="flex items-center space-x-4 mb-4">
                    <img
                      src={testimonial.image}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div>
                      <h4 className="font-semibold">{testimonial.name}</h4>
                      <p className="text-sm text-gray-400">{testimonial.role} at {testimonial.company}</p>
                    </div>
                  </div>
                  <div className="flex mb-4">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 text-nimbo-orange" fill="#FF5F1F" />
                    ))}
                  </div>
                  <p className="text-gray-300">{testimonial.content}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* CTA Section */}
        <div className="bg-nimbo-dark-lighter rounded-lg p-8 text-center">
          <h2 className="text-2xl font-semibold mb-4">Ready to Get Started?</h2>
          <p className="text-gray-400 mb-6">
            Contact our team to learn more about how we can help you achieve your goals with {title}.
          </p>
          <Link
            to="/consultation"
            className="inline-block px-6 py-3 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-lg transition-colors"
          >
            Book a Consultation
          </Link>
        </div>
      </div>
    </div>
  );
}
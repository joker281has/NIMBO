import React from 'react';
import { useParams, Navigate } from 'react-router-dom';
import { 
  Zap, 
  Shield, 
  Cpu, 
  Globe, 
  Cloud, 
  LineChart, 
  Lock, 
  Layers,
  Database,
  Monitor,
  Network,
  Server,
  Code,
  Briefcase,
  Settings,
  Users
} from 'lucide-react';
import ServiceTemplate from './ServiceTemplate';
import { coreServices, businessServices, innovationServices, itServices } from '../../data/services';

const serviceDetails = {
  'ai-ml': {
    features: [
      {
        title: 'Machine Learning Models',
        description: 'Custom ML models trained on your data',
        icon: <Cpu className="w-6 h-6 text-nimbo-orange" />
      },
      {
        title: 'Natural Language Processing',
        description: 'Advanced text and speech processing',
        icon: <Zap className="w-6 h-6 text-nimbo-orange" />
      },
      {
        title: 'Predictive Analytics',
        description: 'Data-driven forecasting and insights',
        icon: <LineChart className="w-6 h-6 text-nimbo-orange" />
      }
    ],
    benefits: [
      'Automate repetitive tasks and workflows',
      'Make data-driven decisions with confidence',
      'Improve customer experience with AI-powered insights',
      'Reduce operational costs through automation',
      'Scale your AI capabilities as you grow'
    ],
    pricing: [
      {
        name: 'Starter',
        price: '$499',
        description: 'Perfect for small businesses starting with AI',
        features: [
          'Basic ML model deployment',
          'API access',
          'Basic analytics dashboard',
          '5 custom predictions/month',
          'Email support'
        ]
      },
      {
        name: 'Professional',
        price: '$999',
        description: 'For growing businesses with advanced needs',
        features: [
          'Advanced ML model deployment',
          'Custom model training',
          'Advanced analytics dashboard',
          'Unlimited predictions',
          'Priority support'
        ],
        highlighted: true
      },
      {
        name: 'Enterprise',
        price: 'Custom',
        description: 'For large organizations with specific requirements',
        features: [
          'Custom ML solution development',
          'On-premises deployment option',
          'Dedicated support team',
          'Custom integrations',
          'SLA guarantees'
        ]
      }
    ],
    testimonials: [
      {
        name: 'Sarah Chen',
        role: 'CTO',
        company: 'TechCorp',
        content: 'Nimbo\'s AI solutions have transformed our business operations. The accuracy of their models and the support team\'s expertise are outstanding.',
        image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150'
      },
      {
        name: 'Michael Rodriguez',
        role: 'Head of Innovation',
        company: 'Future Labs',
        content: 'The implementation was smooth, and the results exceeded our expectations. Our efficiency has improved by 300% since using Nimbo\'s AI services.',
        image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&h=150'
      }
    ]
  },
  'cloud': {
    features: [
      {
        title: 'Global Infrastructure',
        description: 'Worldwide network of data centers for optimal performance',
        icon: <Globe className="w-6 h-6 text-nimbo-orange" />
      },
      {
        title: 'Auto-scaling',
        description: 'Dynamic resource allocation based on demand',
        icon: <Layers className="w-6 h-6 text-nimbo-orange" />
      },
      {
        title: 'High Availability',
        description: '99.99% uptime guarantee with redundant systems',
        icon: <Server className="w-6 h-6 text-nimbo-orange" />
      }
    ],
    benefits: [
      'Reduce infrastructure costs with pay-as-you-go pricing',
      'Scale seamlessly as your business grows',
      'Ensure business continuity with reliable systems',
      'Access enterprise-grade security features',
      'Deploy globally in minutes'
    ],
    pricing: [
      {
        name: 'Basic',
        price: '$299',
        description: 'Essential cloud infrastructure for small applications',
        features: [
          '2 virtual CPUs',
          '4GB RAM',
          '100GB SSD storage',
          'Basic monitoring',
          '99.9% uptime SLA'
        ]
      },
      {
        name: 'Business',
        price: '$799',
        description: 'Advanced infrastructure for growing businesses',
        features: [
          '8 virtual CPUs',
          '16GB RAM',
          '500GB SSD storage',
          'Advanced monitoring',
          '99.99% uptime SLA'
        ],
        highlighted: true
      },
      {
        name: 'Enterprise',
        price: 'Custom',
        description: 'Custom infrastructure solutions for large organizations',
        features: [
          'Custom CPU/RAM configuration',
          'Unlimited storage',
          'Enterprise monitoring',
          'Dedicated support team',
          'Custom SLA options'
        ]
      }
    ],
    testimonials: [
      {
        name: 'David Park',
        role: 'Infrastructure Lead',
        company: 'CloudScale',
        content: 'Nimbo\'s cloud infrastructure has given us the reliability and scalability we needed. Their auto-scaling features have saved us countless hours of manual work.',
        image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150'
      },
      {
        name: 'Emma Thompson',
        role: 'DevOps Manager',
        company: 'TechFlow',
        content: 'The global infrastructure and high availability have been game-changers for our international expansion. Deployment is seamless and performance is exceptional.',
        image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=150&h=150'
      }
    ]
  },
  'security': {
    features: [
      {
        title: 'Threat Detection',
        description: 'Advanced AI-powered security monitoring',
        icon: <Shield className="w-6 h-6 text-nimbo-orange" />
      },
      {
        title: 'Data Encryption',
        description: 'End-to-end encryption for all data',
        icon: <Lock className="w-6 h-6 text-nimbo-orange" />
      },
      {
        title: 'Access Control',
        description: 'Granular permissions and identity management',
        icon: <Users className="w-6 h-6 text-nimbo-orange" />
      }
    ],
    benefits: [
      'Protect sensitive data with military-grade encryption',
      'Prevent security breaches with real-time monitoring',
      'Maintain compliance with industry regulations',
      'Secure access with multi-factor authentication',
      'Regular security audits and updates'
    ],
    pricing: [
      {
        name: 'Essential',
        price: '$599',
        description: 'Basic security features for small businesses',
        features: [
          'Basic threat detection',
          'Standard encryption',
          'Access control',
          'Security reports',
          'Email support'
        ]
      },
      {
        name: 'Advanced',
        price: '$1,499',
        description: 'Comprehensive security for medium businesses',
        features: [
          'Advanced threat detection',
          'Custom security rules',
          'Compliance management',
          'Security dashboard',
          '24/7 support'
        ],
        highlighted: true
      },
      {
        name: 'Enterprise',
        price: 'Custom',
        description: 'Enterprise-grade security solutions',
        features: [
          'Custom security architecture',
          'Dedicated SOC team',
          'Advanced compliance tools',
          'Custom integrations',
          'Incident response team'
        ]
      }
    ],
    testimonials: [
      {
        name: 'James Wilson',
        role: 'Security Director',
        company: 'SecureBank',
        content: 'Nimbo\'s security solutions provide the comprehensive protection we need in the financial sector. Their threat detection system has prevented numerous potential breaches.',
        image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150'
      },
      {
        name: 'Lisa Chen',
        role: 'CISO',
        company: 'DataGuard',
        content: 'The encryption and access control features are top-notch. We\'ve significantly improved our security posture since implementing Nimbo\'s solutions.',
        image: 'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=150&h=150'
      }
    ]
  },
  'development': {
    features: [
      {
        title: 'Custom Development',
        description: 'Tailored software solutions for your needs',
        icon: <Code className="w-6 h-6 text-nimbo-orange" />
      },
      {
        title: 'API Integration',
        description: 'Seamless integration with existing systems',
        icon: <Settings className="w-6 h-6 text-nimbo-orange" />
      },
      {
        title: 'Continuous Deployment',
        description: 'Automated testing and deployment pipeline',
        icon: <Cloud className="w-6 h-6 text-nimbo-orange" />
      }
    ],
    benefits: [
      'Accelerate development with expert teams',
      'Ensure code quality with best practices',
      'Reduce time-to-market for new features',
      'Scale development resources as needed',
      'Maintain consistent deployment processes'
    ],
    pricing: [
      {
        name: 'Startup',
        price: '$5,999',
        description: 'Essential development services for startups',
        features: [
          'Basic development team',
          'Project management',
          'Code repository',
          'Basic testing',
          'Monthly updates'
        ]
      },
      {
        name: 'Growth',
        price: '$12,999',
        description: 'Comprehensive development for growing companies',
        features: [
          'Dedicated development team',
          'Advanced project management',
          'CI/CD pipeline',
          'Comprehensive testing',
          'Weekly updates'
        ],
        highlighted: true
      },
      {
        name: 'Enterprise',
        price: 'Custom',
        description: 'Full-scale development solutions',
        features: [
          'Multiple development teams',
          'Enterprise project management',
          'Custom development tools',
          'Advanced security testing',
          'Daily updates'
        ]
      }
    ],
    testimonials: [
      {
        name: 'Alex Martinez',
        role: 'Product Manager',
        company: 'InnovateTech',
        content: 'The development team at Nimbo has consistently delivered high-quality solutions. Their expertise and commitment to best practices have been invaluable.',
        image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=150&h=150'
      },
      {
        name: 'Rachel Kim',
        role: 'Engineering Director',
        company: 'DevFirst',
        content: 'Working with Nimbo\'s development team has transformed our development process. The continuous deployment pipeline has significantly improved our efficiency.',
        image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&h=150'
      }
    ]
  },
  'analytics': {
    features: [
      {
        title: 'Real-time Analytics',
        description: 'Live data monitoring and analysis',
        icon: <LineChart className="w-6 h-6 text-nimbo-orange" />
      },
      {
        title: 'Data Warehousing',
        description: 'Scalable storage for all your data',
        icon: <Database className="w-6 h-6 text-nimbo-orange" />
      },
      {
        title: 'Custom Dashboards',
        description: 'Personalized visualization tools',
        icon: <Monitor className="w-6 h-6 text-nimbo-orange" />
      }
    ],
    benefits: [
      'Make data-driven decisions with confidence',
      'Identify trends and patterns in real-time',
      'Improve business performance with insights',
      'Centralize data from multiple sources',
      'Customize reports for different stakeholders'
    ],
    pricing: [
      {
        name: 'Starter',
        price: '$399',
        description: 'Essential analytics for small businesses',
        features: [
          'Basic data analysis',
          '5 custom dashboards',
          'Standard reports',
          'Email support',
          'Daily updates'
        ]
      },
      {
        name: 'Professional',
        price: '$899',
        description: 'Advanced analytics for growing businesses',
        features: [
          'Advanced data analysis',
          'Unlimited dashboards',
          'Custom reports',
          'Priority support',
          'Real-time updates'
        ],
        highlighted: true
      },
      {
        name: 'Enterprise',
        price: 'Custom',
        description: 'Enterprise-grade analytics solution',
        features: [
          'Custom analytics solution',
          'Data warehouse integration',
          'Advanced visualization tools',
          'Dedicated support team',
          'Custom update frequency'
        ]
      }
    ],
    testimonials: [
      {
        name: 'Thomas Anderson',
        role: 'Data Analytics Lead',
        company: 'DataDriven',
        content: 'Nimbo\'s analytics platform has revolutionized how we handle data. The real-time insights have helped us make better decisions faster.',
        image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&h=150'
      },
      {
        name: 'Sofia Garcia',
        role: 'Business Intelligence Manager',
        company: 'InsightCo',
        content: 'The custom dashboards and reporting features are exactly what we needed. Our team can now access and analyze data more efficiently than ever.',
        image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=150&h=150'
      }
    ]
  },
  'enterprise': {
    features: [
      {
        title: 'Enterprise Integration',
        description: 'Seamless connection with existing systems',
        icon: <Network className="w-6 h-6 text-nimbo-orange" />
      },
      {
        title: 'Workflow Automation',
        description: 'Streamlined business processes',
        icon: <Settings className="w-6 h-6 text-nimbo-orange" />
      },
      {
        title: 'Resource Management',
        description: 'Efficient allocation of resources',
        icon: <Briefcase className="w-6 h-6 text-nimbo-orange" />
      }
    ],
    benefits: [
      'Streamline operations across departments',
      'Improve efficiency with automated workflows',
      'Enhance collaboration between teams',
      'Reduce operational costs',
      'Scale business processes effectively'
    ],
    pricing: [
      {
        name: 'Department',
        price: '$2,999',
        description: 'Solutions for individual departments',
        features: [
          'Basic integration',
          'Standard automation',
          'Department-level analytics',
          'Email support',
          'Monthly reviews'
        ]
      },
      {
        name: 'Organization',
        price: '$7,999',
        description: 'Company-wide enterprise solutions',
        features: [
          'Full system integration',
          'Advanced automation',
          'Organization-wide analytics',
          'Priority support',
          'Weekly reviews'
        ],
        highlighted: true
      },
      {
        name: 'Global',
        price: 'Custom',
        description: 'Global enterprise solutions',
        features: [
          'Global system integration',
          'Custom automation solutions',
          'Global analytics platform',
          'Dedicated support team',
          'Daily reviews'
        ]
      }
    ],
    testimonials: [
      {
        name: 'Robert Johnson',
        role: 'Enterprise Architect',
        company: 'GlobalCorp',
        content: 'Nimbo\'s enterprise solutions have helped us unify our global operations. The integration capabilities are exceptional, and the support is outstanding.',
        image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150'
      },
      {
        name: 'Maria Santos',
        role: 'Operations Director',
        company: 'Enterprise Solutions',
        content: 'The workflow automation has transformed our business processes. We\'ve seen a significant improvement in efficiency and cost reduction.',
        image: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?auto=format&fit=crop&w=150&h=150'
      }
    ]
  }
};

export default function ServicePage() {
  const { serviceId } = useParams<{ serviceId: string }>();
  
  const allServices = [...coreServices, ...businessServices, ...innovationServices, ...itServices];
  const service = allServices.find(s => s.path === `/services/${serviceId}`);
  const details = serviceId ? serviceDetails[serviceId as keyof typeof serviceDetails] : undefined;
  
  if (!service) {
    return <Navigate to="/" replace />;
  }

  return (
    <ServiceTemplate
      title={service.name}
      description={service.description}
      icon={service.icon}
      features={details?.features}
      benefits={details?.benefits}
      pricing={details?.pricing}
      testimonials={details?.testimonials}
    />
  );
}
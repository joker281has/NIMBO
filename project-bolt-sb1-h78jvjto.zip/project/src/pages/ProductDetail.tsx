import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Star, Share2, Heart, Shield, Server, Clock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useStore } from '../lib/store';
import AddToCartButton from '../components/AddToCartButton';
import ReviewList from '../components/ReviewList';
import ReviewForm from '../components/ReviewForm';
import LoadingSpinner from '../components/LoadingSpinner';
import SEO from '../components/SEO';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image_url: string;
  stock: number;
  rating: number;
  features: string[];
  specifications: Record<string, string>;
}

export default function ProductDetail() {
  const { productId } = useParams<{ productId: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedImage, setSelectedImage] = useState(0);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const { wishlist, addToWishlist, removeFromWishlist } = useStore();

  const isInWishlist = wishlist.some(item => item.id === productId);

  useEffect(() => {
    loadProduct();
  }, [productId]);

  async function loadProduct() {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('id', productId)
        .single();

      if (error) throw error;
      setProduct(data);
    } catch (err) {
      setError('Failed to load product');
      console.error('Error loading product:', err);
    } finally {
      setLoading(false);
    }
  }

  const handleShare = async () => {
    try {
      await navigator.share({
        title: product?.name,
        text: product?.description,
        url: window.location.href
      });
    } catch (err) {
      console.error('Error sharing:', err);
    }
  };

  const handleWishlist = () => {
    if (!product) return;
    
    if (isInWishlist) {
      removeFromWishlist(product.id);
    } else {
      addToWishlist({
        id: product.id,
        name: product.name,
        price: product.price
      });
    }
  };

  if (loading) return <LoadingSpinner fullScreen />;
  if (error || !product) {
    return (
      <div className="min-h-screen bg-nimbo-dark p-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-4 text-red-500">
            {error || 'Product not found'}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-nimbo-dark p-8">
      <SEO 
        title={product.name}
        description={product.description}
        type="product"
        schema={{
          "@context": "https://schema.org/",
          "@type": "Product",
          "name": product.name,
          "description": product.description,
          "image": product.image_url,
          "offers": {
            "@type": "Offer",
            "price": product.price,
            "priceCurrency": "USD"
          }
        }}
      />

      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <Link 
            to="/products" 
            className="text-gray-400 hover:text-white transition-colors"
          >
            ← Back to Products
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-w-4 aspect-h-3 bg-nimbo-dark-lighter rounded-lg overflow-hidden">
              <img
                src={product.image_url}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {[...Array(4)].map((_, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`aspect-w-1 aspect-h-1 rounded-lg overflow-hidden ${
                    selectedImage === index ? 'ring-2 ring-nimbo-orange' : ''
                  }`}
                >
                  <img
                    src={product.image_url}
                    alt={`${product.name} view ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div>
            <div className="mb-6">
              <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
              <div className="flex items-center space-x-4 mb-4">
                <div className="flex items-center">
                  {[...Array(5)].map((_, index) => (
                    <Star
                      key={index}
                      className={`w-5 h-5 ${
                        index < product.rating
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-400'
                      }`}
                    />
                  ))}
                  <span className="ml-2 text-gray-400">({product.rating})</span>
                </div>
                <button
                  onClick={handleShare}
                  className="p-2 hover:bg-nimbo-dark rounded-lg transition-colors"
                >
                  <Share2 className="w-5 h-5" />
                </button>
                <button
                  onClick={handleWishlist}
                  className={`p-2 rounded-lg transition-colors ${
                    isInWishlist ? 'text-red-500' : 'hover:bg-nimbo-dark'
                  }`}
                >
                  <Heart className={isInWishlist ? 'fill-current' : ''} />
                </button>
              </div>
              <p className="text-gray-400">{product.description}</p>
            </div>

            <div className="mb-8">
              <div className="text-3xl font-bold text-nimbo-orange mb-4">
                ${product.price}
              </div>
              <AddToCartButton item={product} variant="primary" />
            </div>

            {/* Features */}
            <div className="grid grid-cols-2 gap-4 mb-8">
              <div className="flex items-center space-x-3 p-4 bg-nimbo-dark rounded-lg">
                <Shield className="w-6 h-6 text-nimbo-orange" />
                <div>
                  <div className="font-medium">Secure</div>
                  <div className="text-sm text-gray-400">Enterprise-grade security</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-4 bg-nimbo-dark rounded-lg">
                <Server className="w-6 h-6 text-nimbo-orange" />
                <div>
                  <div className="font-medium">Scalable</div>
                  <div className="text-sm text-gray-400">Grows with your needs</div>
                </div>
              </div>
              <div className="flex items-center space-x-3 p-4 bg-nimbo-dark rounded-lg">
                <Clock className="w-6 h-6 text-nimbo-orange" />
                <div>
                  <div className="font-medium">24/7 Support</div>
                  <div className="text-sm text-gray-400">Always available</div>
                </div>
              </div>
            </div>

            {/* Specifications */}
            <div className="border-t border-nimbo-dark pt-8">
              <h2 className="text-xl font-semibold mb-4">Specifications</h2>
              <dl className="grid grid-cols-1 gap-4">
                {Object.entries(product.specifications).map(([key, value]) => (
                  <div key={key} className="flex">
                    <dt className="w-1/3 text-gray-400">{key}</dt>
                    <dd className="w-2/3">{value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="mt-16">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold">Customer Reviews</h2>
            <button
              onClick={() => setShowReviewForm(true)}
              className="px-4 py-2 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-lg transition-colors"
            >
              Write a Review
            </button>
          </div>

          {showReviewForm && (
            <div className="mb-8">
              <ReviewForm
                productId={product.id}
                onSuccess={() => {
                  setShowReviewForm(false);
                  loadProduct();
                }}
              />
            </div>
          )}

          <ReviewList
            reviews={[]}
            onHelpful={() => {}}
            onReport={() => {}}
          />
        </div>
      </div>
    </div>
  );
}
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Package, Search, Filter, ChevronDown } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { getOrders, formatOrderDate, getOrderStatus, type Order } from '../lib/orders';
import LoadingSpinner from '../components/LoadingSpinner';
import SEO from '../components/SEO';

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<Order['status'] | 'all'>('all');

  useEffect(() => {
    loadOrders();
  }, []);

  async function loadOrders() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      const orders = await getOrders(user.id);
      setOrders(orders);
    } catch (err) {
      setError('Failed to load orders');
      console.error('Error loading orders:', err);
    } finally {
      setLoading(false);
    }
  }

  const filteredOrders = orders.filter(order => {
    if (statusFilter !== 'all' && order.status !== statusFilter) return false;
    if (searchQuery) {
      const searchLower = searchQuery.toLowerCase();
      return (
        order.id.toLowerCase().includes(searchLower) ||
        order.items.some(item => 
          item.name.toLowerCase().includes(searchLower)
        )
      );
    }
    return true;
  });

  if (loading) return <LoadingSpinner fullScreen />;

  return (
    <div className="min-h-screen bg-nimbo-dark p-8">
      <SEO 
        title="Orders"
        description="View and manage your orders"
      />

      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-8">Orders</h1>

        {error ? (
          <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-4 text-red-500">
            {error}
          </div>
        ) : (
          <>
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
              {/* Search */}
              <div className="relative w-full md:w-96">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search orders..."
                  className="w-full pl-10 pr-4 py-2 bg-nimbo-dark-lighter border border-nimbo-dark rounded-lg"
                />
              </div>

              {/* Filter */}
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Filter className="w-5 h-5 text-gray-400" />
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value as Order['status'] | 'all')}
                    className="bg-nimbo-dark-lighter border border-nimbo-dark rounded-lg px-3 py-2"
                  >
                    <option value="all">All Orders</option>
                    <option value="pending">Pending</option>
                    <option value="processing">Processing</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>
              </div>
            </div>

            {filteredOrders.length === 0 ? (
              <div className="text-center py-12">
                <Package className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h2 className="text-xl font-semibold mb-2">No Orders Found</h2>
                <p className="text-gray-400 mb-4">
                  {orders.length === 0
                    ? "You haven't placed any orders yet"
                    : "No orders match your search criteria"
                }
                </p>
                <Link
                  to="/products"
                  className="inline-block px-6 py-3 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-lg transition-colors"
                >
                  Browse Products
                </Link>
              </div>
            ) : (
              <div className="space-y-6">
                {filteredOrders.map(order => {
                  const status = getOrderStatus(order.status);
                  return (
                    <div
                      key={order.id}
                      className="bg-nimbo-dark-lighter rounded-lg overflow-hidden"
                    >
                      {/* Order Header */}
                      <div className="p-4 border-b border-nimbo-dark flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div>
                          <div className="text-sm text-gray-400">Order ID</div>
                          <div className="font-medium">{order.id}</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-400">Order Date</div>
                          <div>{formatOrderDate(order.createdAt)}</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-400">Total</div>
                          <div className="font-medium">${order.total.toFixed(2)}</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-400">Status</div>
                          <div className={status.color}>{status.label}</div>
                        </div>
                        <Link
                          to={`/orders/${order.id}`}
                          className="flex items-center space-x-1 text-nimbo-orange hover:text-nimbo-orange-light transition-colors"
                        >
                          <span>View Details</span>
                          <ChevronDown className="w-4 h-4" />
                        </Link>
                      </div>

                      {/* Order Items */}
                      <div className="p-4">
                        <div className="space-y-4">
                          {order.items.map((item, index) => (
                            <div
                              key={index}
                              className="flex items-center space-x-4"
                            >
                              <div className="w-16 h-16 bg-nimbo-dark rounded-lg flex items-center justify-center">
                                <Package className="w-8 h-8 text-gray-400" />
                              </div>
                              <div className="flex-1">
                                <div className="font-medium">{item.name}</div>
                                <div className="text-sm text-gray-400">
                                  Quantity: {item.quantity}
                                </div>
                              </div>
                              <div className="font-medium">
                                ${(item.price * item.quantity).toFixed(2)}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
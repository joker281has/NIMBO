import React, { useState, useEffect } from 'react';
import { Grid, List, Filter, Search, SortAsc, SortDesc } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useStore } from '../lib/store';
import { SearchService } from '../lib/search';
import AddToCartButton from '../components/AddToCartButton';
import LoadingSpinner from '../components/LoadingSpinner';
import SEO from '../components/SEO';

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image_url: string;
  stock: number;
  rating: number;
  tags: string[];
}

interface FilterState {
  category: string[];
  price: { min: number; max: number };
  rating: number;
}

export default function Products() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [view, setView] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'price' | 'rating'>('rating');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState<FilterState>({
    category: [],
    price: { min: 0, max: 1000 },
    rating: 0
  });

  const searchService = new SearchService(products);

  useEffect(() => {
    loadProducts();
  }, []);

  async function loadProducts() {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*');

      if (error) throw error;
      setProducts(data);
    } catch (err) {
      setError('Failed to load products');
      console.error('Error loading products:', err);
    } finally {
      setLoading(false);
    }
  }

  const filteredProducts = React.useMemo(() => {
    let result = [...products];

    // Apply search
    if (searchQuery) {
      const searchResults = searchService.search(searchQuery);
      result = searchResults.map(r => r.item);
    }

    // Apply filters
    if (filters.category.length > 0) {
      result = result.filter(p => filters.category.includes(p.category));
    }
    result = result.filter(p => 
      p.price >= filters.price.min && 
      p.price <= filters.price.max &&
      p.rating >= filters.rating
    );

    // Apply sorting
    result.sort((a, b) => {
      const factor = sortOrder === 'asc' ? 1 : -1;
      return (a[sortBy] - b[sortBy]) * factor;
    });

    return result;
  }, [products, searchQuery, filters, sortBy, sortOrder]);

  if (loading) return <LoadingSpinner fullScreen />;

  return (
    <div className="min-h-screen bg-nimbo-dark p-8">
      <SEO 
        title="Products"
        description="Browse our collection of cloud computing and enterprise solutions"
      />

      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <h1 className="text-3xl font-bold">Products</h1>

          <div className="flex items-center space-x-4">
            {/* View Toggle */}
            <div className="flex items-center space-x-2 bg-nimbo-dark-lighter rounded-lg p-1">
              <button
                onClick={() => setView('grid')}
                className={`p-2 rounded ${view === 'grid' ? 'bg-nimbo-dark' : ''}`}
              >
                <Grid className="w-5 h-5" />
              </button>
              <button
                onClick={() => setView('list')}
                className={`p-2 rounded ${view === 'list' ? 'bg-nimbo-dark' : ''}`}
              >
                <List className="w-5 h-5" />
              </button>
            </div>

            {/* Sort Controls */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'price' | 'rating')}
              className="bg-nimbo-dark-lighter border border-nimbo-dark rounded-lg px-3 py-2"
            >
              <option value="rating">Sort by Rating</option>
              <option value="price">Sort by Price</option>
            </select>

            <button
              onClick={() => setSortOrder(order => order === 'asc' ? 'desc' : 'asc')}
              className="p-2 bg-nimbo-dark-lighter rounded-lg"
            >
              {sortOrder === 'asc' ? <SortAsc className="w-5 h-5" /> : <SortDesc className="w-5 h-5" />}
            </button>
          </div>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className="w-full md:w-64 space-y-6">
            <div className="bg-nimbo-dark-lighter rounded-lg p-4">
              <h2 className="font-semibold mb-4 flex items-center">
                <Filter className="w-5 h-5 mr-2" />
                Filters
              </h2>

              {/* Search */}
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search products..."
                  className="w-full pl-10 pr-4 py-2 bg-nimbo-dark border border-nimbo-dark-lighter rounded-lg"
                />
              </div>

              {/* Category Filter */}
              <div className="mb-4">
                <h3 className="text-sm font-medium mb-2">Category</h3>
                {['Infrastructure', 'Security', 'Analytics', 'AI'].map(category => (
                  <label key={category} className="flex items-center space-x-2 mb-2">
                    <input
                      type="checkbox"
                      checked={filters.category.includes(category)}
                      onChange={(e) => {
                        setFilters(prev => ({
                          ...prev,
                          category: e.target.checked
                            ? [...prev.category, category]
                            : prev.category.filter(c => c !== category)
                        }));
                      }}
                      className="rounded border-gray-300 text-nimbo-orange focus:ring-nimbo-orange"
                    />
                    <span className="text-sm">{category}</span>
                  </label>
                ))}
              </div>

              {/* Price Range Filter */}
              <div className="mb-4">
                <h3 className="text-sm font-medium mb-2">Price Range</h3>
                <div className="flex items-center space-x-2">
                  <input
                    type="number"
                    value={filters.price.min}
                    onChange={(e) => setFilters(prev => ({
                      ...prev,
                      price: { ...prev.price, min: Number(e.target.value) }
                    }))}
                    className="w-20 px-2 py-1 bg-nimbo-dark border border-nimbo-dark-lighter rounded"
                  />
                  <span>to</span>
                  <input
                    type="number"
                    value={filters.price.max}
                    onChange={(e) => setFilters(prev => ({
                      ...prev,
                      price: { ...prev.price, max: Number(e.target.value) }
                    }))}
                    className="w-20 px-2 py-1 bg-nimbo-dark border border-nimbo-dark-lighter rounded"
                  />
                </div>
              </div>

              {/* Rating Filter */}
              <div>
                <h3 className="text-sm font-medium mb-2">Minimum Rating</h3>
                <input
                  type="range"
                  min="0"
                  max="5"
                  step="0.5"
                  value={filters.rating}
                  onChange={(e) => setFilters(prev => ({
                    ...prev,
                    rating: Number(e.target.value)
                  }))}
                  className="w-full"
                />
                <div className="text-sm text-gray-400">{filters.rating} stars</div>
              </div>
            </div>
          </div>

          {/* Product Grid/List */}
          <div className="flex-1">
            {error ? (
              <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-4 text-red-500">
                {error}
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-12 text-gray-400">
                No products found matching your criteria
              </div>
            ) : (
              <div className={view === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6' : 'space-y-4'}>
                {filteredProducts.map(product => (
                  <div
                    key={product.id}
                    className={`bg-nimbo-dark-lighter rounded-lg overflow-hidden ${
                      view === 'list' ? 'flex' : ''
                    }`}
                  >
                    <img
                      src={product.image_url}
                      alt={product.name}
                      className={view === 'list' ? 'w-48 h-48 object-cover' : 'w-full h-48 object-cover'}
                    />
                    <div className="p-4">
                      <h3 className="font-semibold mb-2">{product.name}</h3>
                      <p className="text-sm text-gray-400 mb-4">{product.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-bold text-nimbo-orange">
                          ${product.price}
                        </span>
                        <AddToCartButton item={product} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
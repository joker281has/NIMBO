import React, { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Server, Activity, Database, Settings, CreditCard, Bell, Users, Shield, LineChart } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import SEO from '../components/SEO';

interface UsageMetrics {
  servers: number;
  storage: number;
  bandwidth: number;
  users: number;
}

interface BillingInfo {
  plan: string;
  amount: number;
  nextBilling: string;
  status: 'active' | 'past_due' | 'canceled';
}

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [userDetails, setUserDetails] = useState<any>(null);
  const [metrics, setMetrics] = useState<UsageMetrics>({
    servers: 0,
    storage: 0,
    bandwidth: 0,
    users: 0
  });
  const [billing, setBilling] = useState<BillingInfo>({
    plan: 'Free',
    amount: 0,
    nextBilling: new Date().toISOString(),
    status: 'active'
  });

  useEffect(() => {
    loadDashboardData();
  }, []);

  async function loadDashboardData() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('No user found');

      // Load user profile
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      setUserDetails({ ...user, ...profile });

      // In a real app, load actual metrics and billing info
      // For demo, using mock data
      setMetrics({
        servers: 3,
        storage: 250,
        bandwidth: 1.5,
        users: 12
      });

    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <LoadingSpinner fullScreen />;

  return (
    <div className="min-h-screen bg-nimbo-dark p-8">
      <SEO 
        title="Dashboard"
        description="Manage your cloud resources and monitor performance"
      />

      <div className="max-w-7xl mx-auto">
        {error ? (
          <div className="bg-red-500/10 border border-red-500/50 rounded-lg p-4 text-red-500">
            {error}
          </div>
        ) : (
          <>
            {/* Header */}
            <header className="mb-8">
              <h1 className="text-3xl font-bold mb-2">
                Welcome back, {userDetails?.full_name || userDetails?.email}
              </h1>
              <p className="text-gray-400">
                Here's what's happening with your cloud resources today
              </p>
            </header>

            {/* Quick Stats */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
              <div className="bg-nimbo-dark-lighter rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">Active Servers</h3>
                  <Server className="text-nimbo-orange" />
                </div>
                <p className="text-3xl font-bold">{metrics.servers}</p>
                <p className="text-sm text-gray-400 mt-2">2 running, 1 stopped</p>
              </div>

              <div className="bg-nimbo-dark-lighter rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">Storage Used</h3>
                  <Database className="text-nimbo-orange" />
                </div>
                <p className="text-3xl font-bold">{metrics.storage}GB</p>
                <p className="text-sm text-gray-400 mt-2">of 500GB quota</p>
              </div>

              <div className="bg-nimbo-dark-lighter rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">Bandwidth</h3>
                  <Activity className="text-nimbo-orange" />
                </div>
                <p className="text-3xl font-bold">{metrics.bandwidth}TB</p>
                <p className="text-sm text-gray-400 mt-2">Monthly usage</p>
              </div>

              <div className="bg-nimbo-dark-lighter rounded-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">Team Members</h3>
                  <Users className="text-nimbo-orange" />
                </div>
                <p className="text-3xl font-bold">{metrics.users}</p>
                <p className="text-sm text-gray-400 mt-2">Active users</p>
              </div>
            </div>

            {/* Main Content */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Resource Usage */}
              <div className="lg:col-span-2 space-y-8">
                <div className="bg-nimbo-dark-lighter rounded-lg p-6">
                  <h2 className="text-xl font-semibold mb-6 flex items-center">
                    <LineChart className="w-5 h-5 mr-2 text-nimbo-orange" />
                    Resource Usage
                  </h2>
                  <div className="h-64 flex items-center justify-center border-2 border-dashed border-nimbo-dark rounded-lg">
                    <p className="text-gray-400">Resource usage graph will be displayed here</p>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="bg-nimbo-dark-lighter rounded-lg p-6">
                  <h2 className="text-xl font-semibold mb-6 flex items-center">
                    <Bell className="w-5 h-5 mr-2 text-nimbo-orange" />
                    Recent Activity
                  </h2>
                  <div className="space-y-4">
                    {[
                      { text: 'New server deployed', time: '2 hours ago' },
                      { text: 'Database backup completed', time: '5 hours ago' },
                      { text: 'Security update installed', time: '1 day ago' }
                    ].map((activity, index) => (
                      <div key={index} className="flex items-center justify-between py-2 border-b border-nimbo-dark last:border-0">
                        <span>{activity.text}</span>
                        <span className="text-sm text-gray-400">{activity.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Sidebar */}
              <div className="space-y-8">
                {/* Billing Summary */}
                <div className="bg-nimbo-dark-lighter rounded-lg p-6">
                  <h2 className="text-xl font-semibold mb-6 flex items-center">
                    <CreditCard className="w-5 h-5 mr-2 text-nimbo-orange" />
                    Billing Summary
                  </h2>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Current Plan</span>
                      <span className="font-medium">{billing.plan}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Amount Due</span>
                      <span className="font-medium">${billing.amount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">Next Billing</span>
                      <span className="font-medium">
                        {new Date(billing.nextBilling).toLocaleDateString()}
                      </span>
                    </div>
                    <button className="w-full mt-4 px-4 py-2 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-lg transition-colors">
                      Manage Billing
                    </button>
                  </div>
                </div>

                {/* Security Status */}
                <div className="bg-nimbo-dark-lighter rounded-lg p-6">
                  <h2 className="text-xl font-semibold mb-6 flex items-center">
                    <Shield className="w-5 h-5 mr-2 text-nimbo-orange" />
                    Security Status
                  </h2>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Two-Factor Auth</span>
                      <span className="px-2 py-1 bg-green-500/10 text-green-500 rounded text-sm">
                        Enabled
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>SSL Certificates</span>
                      <span className="px-2 py-1 bg-green-500/10 text-green-500 rounded text-sm">
                        Valid
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Last Security Scan</span>
                      <span className="text-sm text-gray-400">2 days ago</span>
                    </div>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="bg-nimbo-dark-lighter rounded-lg p-6">
                  <h2 className="text-xl font-semibold mb-6 flex items-center">
                    <Settings className="w-5 h-5 mr-2 text-nimbo-orange" />
                    Quick Actions
                  </h2>
                  <div className="space-y-3">
                    <button className="w-full px-4 py-2 bg-nimbo-dark hover:bg-nimbo-dark-light rounded-lg transition-colors text-left">
                      Deploy New Server
                    </button>
                    <button className="w-full px-4 py-2 bg-nimbo-dark hover:bg-nimbo-dark-light rounded-lg transition-colors text-left">
                      Create Database
                    </button>
                    <button className="w-full px-4 py-2 bg-nimbo-dark hover:bg-nimbo-dark-light rounded-lg transition-colors text-left">
                      Invite Team Member
                    </button>
                    <button className="w-full px-4 py-2 bg-nimbo-dark hover:bg-nimbo-dark-light rounded-lg transition-colors text-left">
                      View Documentation
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
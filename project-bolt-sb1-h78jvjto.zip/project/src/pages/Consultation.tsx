import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Calendar, Clock, Mail, MessageSquare, User, ChevronLeft, CreditCard, AppleIcon } from 'lucide-react';
import GradientBackground from '../components/GradientBackground';
import { loadStripe } from '@stripe/stripe-js';
import { coreServices, businessServices, innovationServices, itServices } from '../data/services';
import { supabase } from '../lib/supabase';

// Service pricing map
const servicePricing: { [key: string]: number } = {
  'AI & Machine Learning': 499,
  'Cloud Infrastructure': 299,
  'Cybersecurity': 599,
  'Software Development': 799,
  'Business Intelligence': 399,
  'Enterprise Solutions': 999,
  'Digital Transformation': 699,
  '24/7 Support': 199
};

interface FormData {
  name: string;
  email: string;
  service: string;
  date: string;
  time: string;
  message: string;
}

const stripePromise = loadStripe('pk_test_51OqXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX');

// Get user's timezone
const userTimezone = Intl.DateTimeFormat().resolvedOptions().timeZone;

export default function Consultation() {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    service: '',
    date: '',
    time: '',
    message: ''
  });
  const [step, setStep] = useState<'form' | 'payment'>('form');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitAttempted, setSubmitAttempted] = useState(false);
  const [availableSlots, setAvailableSlots] = useState<string[]>([]);

  const allServices = [...coreServices, ...businessServices, ...innovationServices, ...itServices];

  // Load available time slots for selected date
  useEffect(() => {
    if (formData.date) {
      // In a real app, this would fetch from your backend
      // For demo, generate slots between 9 AM and 5 PM
      const slots = [];
      for (let hour = 9; hour < 17; hour++) {
        slots.push(`${hour.toString().padStart(2, '0')}:00`);
        slots.push(`${hour.toString().padStart(2, '0')}:30`);
      }
      setAvailableSlots(slots);
    }
  }, [formData.date]);

  const validateForm = () => {
    if (!formData.name || !formData.email || !formData.service || !formData.date || !formData.time || !formData.message) {
      setError('Please fill in all required fields');
      return false;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError('Please enter a valid email address');
      return false;
    }

    // Validate date is not in the past
    const selectedDate = new Date(formData.date);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (selectedDate < today) {
      setError('Please select a future date');
      return false;
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitAttempted(true);
    setError(null);

    if (!validateForm()) return;

    try {
      // Save consultation to database
      const { error: dbError } = await supabase
        .from('consultations')
        .insert([
          {
            name: formData.name,
            email: formData.email,
            service: formData.service,
            preferred_date: formData.date,
            preferred_time: formData.time,
            message: formData.message,
            timezone: userTimezone
          }
        ]);

      if (dbError) throw dbError;
      setStep('payment');
    } catch (err) {
      setError('Failed to save consultation. Please try again.');
      console.error('Database error:', err);
    }
  };

  const handleStripePayment = async () => {
    setLoading(true);
    try {
      const stripe = await stripePromise;
      if (!stripe) throw new Error('Stripe failed to load');

      // Here you would typically:
      // 1. Call your backend to create a payment intent
      // 2. Update consultation status
      // For demo, simulate success
      await new Promise(resolve => setTimeout(resolve, 1500));

      // Send confirmation email (mock)
      console.log('Sending confirmation email to:', formData.email);

      setSuccess(true);
    } catch (err) {
      setError('Payment failed. Please try again.');
      console.error('Payment error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleApplePay = async () => {
    setLoading(true);
    try {
      const stripe = await stripePromise;
      if (!stripe) throw new Error('Stripe failed to load');

      const paymentRequest = stripe.paymentRequest({
        country: 'US',
        currency: 'usd',
        total: {
          label: formData.service,
          amount: servicePricing[formData.service] * 100,
        },
        requestPayerName: true,
        requestPayerEmail: true,
      });

      const canMakePayment = await paymentRequest.canMakePayment();
      if (!canMakePayment) {
        throw new Error('Apple Pay is not available on this device');
      }

      // For demo, simulate success
      await new Promise(resolve => setTimeout(resolve, 1500));
      setSuccess(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Apple Pay failed. Please try again.');
      console.error('Apple Pay error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setError(null); // Clear errors on input change
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  if (success) {
    return (
      <div className="min-h-screen relative flex items-center justify-center px-4">
        <GradientBackground />
        <div className="relative z-10 max-w-md w-full text-center">
          <div className="bg-nimbo-dark-lighter p-8 rounded-lg shadow-xl border border-nimbo-dark">
            <div className="w-16 h-16 bg-nimbo-orange/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <MessageSquare className="w-8 h-8 text-nimbo-orange" />
            </div>
            <h2 className="text-2xl font-bold mb-4">Thank You!</h2>
            <p className="text-gray-400 mb-6">
              Your consultation has been booked and payment processed. We've sent a confirmation email with the details.
            </p>
            <div className="space-y-4">
              <div className="p-4 bg-nimbo-dark rounded-lg text-left">
                <h3 className="font-semibold mb-2">Booking Details</h3>
                <div className="space-y-2 text-gray-400">
                  <p><span className="text-white">Service:</span> {formData.service}</p>
                  <p><span className="text-white">Date:</span> {formData.date}</p>
                  <p><span className="text-white">Time:</span> {formData.time} ({userTimezone})</p>
                </div>
              </div>
              <Link 
                to="/"
                className="inline-block px-6 py-3 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-lg transition-colors"
              >
                Return to Home
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative">
      <GradientBackground />
      
      <div className="relative container mx-auto px-4 py-20">
        <Link 
          to="/" 
          className="inline-flex items-center space-x-2 text-gray-400 hover:text-white mb-8 group"
        >
          <ChevronLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
          <span>Back to Home</span>
        </Link>

        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold mb-4">Book a Consultation</h1>
            <p className="text-xl text-gray-400">
              Schedule a consultation with our experts to discuss your needs
            </p>
          </div>

          <div className="bg-nimbo-dark-lighter rounded-lg p-8 shadow-xl border border-nimbo-dark">
            {error && (
              <div className="mb-6 p-4 bg-red-500/10 border border-red-500/50 rounded-lg text-red-500">
                {error}
              </div>
            )}

            {step === 'form' ? (
              <form onSubmit={handleSubmit} className="space-y-6" noValidate>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-1">
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        id="name"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className={`w-full pl-10 pr-4 py-2 bg-nimbo-dark border rounded-md focus:outline-none focus:ring-2 focus:ring-nimbo-orange/50 text-white ${
                          submitAttempted && !formData.name ? 'border-red-500' : 'border-nimbo-dark-lighter'
                        }`}
                        placeholder="Enter your name"
                        required
                        aria-required="true"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">
                      Email Address <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="email"
                        id="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className={`w-full pl-10 pr-4 py-2 bg-nimbo-dark border rounded-md focus:outline-none focus:ring-2 focus:ring-nimbo-orange/50 text-white ${
                          submitAttempted && !formData.email ? 'border-red-500' : 'border-nimbo-dark-lighter'
                        }`}
                        placeholder="Enter your email"
                        required
                        aria-required="true"
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <label htmlFor="service" className="block text-sm font-medium text-gray-300 mb-1">
                    Service of Interest <span className="text-red-500">*</span>
                  </label>
                  <select
                    id="service"
                    name="service"
                    value={formData.service}
                    onChange={handleChange}
                    className={`w-full px-4 py-2 bg-nimbo-dark border rounded-md focus:outline-none focus:ring-2 focus:ring-nimbo-orange/50 text-white ${
                      submitAttempted && !formData.service ? 'border-red-500' : 'border-nimbo-dark-lighter'
                    }`}
                    required
                    aria-required="true"
                  >
                    <option value="">Select a service</option>
                    {allServices.map((service, index) => (
                      <option key={index} value={service.name}>
                        {service.name} - ${servicePricing[service.name]}/month
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="date" className="block text-sm font-medium text-gray-300 mb-1">
                      Preferred Date <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="date"
                        id="date"
                        name="date"
                        value={formData.date}
                        onChange={handleChange}
                        min={new Date().toISOString().split('T')[0]}
                        className={`w-full pl-10 pr-4 py-2 bg-nimbo-dark border rounded-md focus:outline-none focus:ring-2 focus:ring-nimbo-orange/50 text-white ${
                          submitAttempted && !formData.date ? 'border-red-500' : 'border-nimbo-dark-lighter'
                        }`}
                        required
                        aria-required="true"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="time" className="block text-sm font-medium text-gray-300 mb-1">
                      Preferred Time <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Clock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <select
                        id="time"
                        name="time"
                        value={formData.time}
                        onChange={handleChange}
                        className={`w-full pl-10 pr-4 py-2 bg-nimbo-dark border rounded-md focus:outline-none focus:ring-2 focus:ring-nimbo-orange/50 text-white ${
                          submitAttempted && !formData.time ? 'border-red-500' : 'border-nimbo-dark-lighter'
                        }`}
                        required
                        aria-required="true"
                        disabled={!formData.date}
                      >
                        <option value="">Select a time</option>
                        {availableSlots.map((slot) => (
                          <option key={slot} value={slot}>
                            {slot}
                          </option>
                        ))}
                      </select>
                    </div>
                    <p className="mt-1 text-sm text-gray-400">All times are in your local timezone ({userTimezone})</p>
                  </div>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-1">
                    Message <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={4}
                    className={`w-full px-4 py-2 bg-nimbo-dark border rounded-md focus:outline-none focus:ring-2 focus:ring-nimbo-orange/50 text-white ${
                      submitAttempted && !formData.message ? 'border-red-500' : 'border-nimbo-dark-lighter'
                    }`}
                    placeholder="Tell us about your project or requirements"
                    required
                    aria-required="true"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 px-4 bg-nimbo-orange hover:bg-nimbo-orange-light text-white rounded-md transition-all duration-200 hover:shadow-lg hover:shadow-nimbo-orange/20 disabled:opacity-50"
                >
                  {loading ? 'Processing...' : 'Continue to Payment'}
                </button>
              </form>
            ) : (
              <div className="space-y-6">
                <div className="p-4 bg-nimbo-dark rounded-lg">
                  <h3 className="font-semibold mb-2">Booking Summary</h3>
                  <div className="space-y-2 text-gray-400">
                    <p><span className="text-white">Service:</span> {formData.service}</p>
                    <p><span className="text-white">Date:</span> {formData.date}</p>
                    <p><span className="text-white">Time:</span> {formData.time} ({userTimezone})</p>
                    <p className="text-xl font-bold text-nimbo-orange">
                      Total: ${servicePricing[formData.service]}
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <button
                    onClick={handleStripePayment}
                    disabled={loading}
                    className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-nimbo-orange hover:bg-nimbo-orange-light rounded-lg transition-colors disabled:opacity-50"
                  >
                    <CreditCard className="w-5 h-5" />
                    <span>{loading ? 'Processing...' : 'Pay with Card'}</span>
                  </button>

                  <button
                    onClick={handleApplePay}
                    disabled={loading}
                    className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-black hover:bg-gray-900 rounded-lg transition-colors disabled:opacity-50"
                  >
                    <AppleIcon className="w-5 h-5" />
                    <span>{loading ? 'Processing...' : 'Pay with Apple Pay'}</span>
                  </button>

                  <button
                    onClick={() => setStep('form')}
                    disabled={loading}
                    className="w-full py-2 text-gray-400 hover:text-white transition-colors disabled:opacity-50"
                  >
                    Back to Form
                  </button>
                </div>

                <p className="text-sm text-center text-gray-400">
                  Secure payment powered by Stripe
                  <br />
                  <span className="text-xs">(Test Mode - No actual charges will be made)</span>
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
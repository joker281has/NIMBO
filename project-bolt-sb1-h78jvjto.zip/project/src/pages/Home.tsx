import React from 'react';
import { Link } from 'react-router-dom';
import { Server, Brain, Cpu, Network, ChevronRight } from 'lucide-react';
import FloatingServer from '../components/FloatingServer';
import GradientBackground from '../components/GradientBackground';
import AnimatedScenes from '../components/AnimatedScenes';

export default function Home() {
  return (
    <div>
      <GradientBackground />
      
      <section className="relative container mx-auto px-4 pt-20 pb-32">
        <div className="max-w-3xl">
          <h1 className="hero-title text-5xl md:text-6xl font-bold mb-6">
            <span className="block">The Future of</span>
            <span className="block text-nimbo-orange">Cloud Computing</span>
            <span className="block">is Here</span>
          </h1>
          <p className="hero-description text-xl text-gray-400 mb-8">
            Experience lightning-fast, secure, and scalable cloud infrastructure designed for modern applications.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link 
              to="/signup" 
              className="px-8 py-4 rounded-lg bg-nimbo-orange hover:bg-nimbo-orange-light transition-colors text-center font-semibold"
            >
              Get Started Free
            </Link>
            <Link 
              to="/docs" 
              className="px-8 py-4 rounded-lg bg-nimbo-dark-lighter hover:bg-nimbo-dark-light transition-colors text-center font-semibold group"
            >
              View Documentation
              <ChevronRight className="inline-block ml-2 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
        
        <FloatingServer />
      </section>

      {/* Animated Scenes Section */}
      <section className="relative h-[600px] overflow-hidden">
        <AnimatedScenes />
      </section>

      <section className="features-section relative container mx-auto px-4 py-32">
        <h2 className="text-3xl md:text-4xl font-bold text-center mb-16">
          Why Choose <span className="text-nimbo-orange">Nimbo</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="feature-card p-6 rounded-lg bg-nimbo-dark-lighter hover:bg-nimbo-dark-light transition-colors">
            <Server className="w-12 h-12 text-nimbo-orange mb-4" />
            <h3 className="text-xl font-semibold mb-2">Instant Deployment</h3>
            <p className="text-gray-400">Deploy your applications in seconds with our automated infrastructure.</p>
          </div>

          <div className="feature-card p-6 rounded-lg bg-nimbo-dark-lighter hover:bg-nimbo-dark-light transition-colors">
            <Brain className="w-12 h-12 text-nimbo-orange mb-4" />
            <h3 className="text-xl font-semibold mb-2">AI-Powered Scaling</h3>
            <p className="text-gray-400">Smart resource allocation that adapts to your application's needs.</p>
          </div>

          <div className="feature-card p-6 rounded-lg bg-nimbo-dark-lighter hover:bg-nimbo-dark-light transition-colors">
            <Cpu className="w-12 h-12 text-nimbo-orange mb-4" />
            <h3 className="text-xl font-semibold mb-2">Edge Computing</h3>
            <p className="text-gray-400">Global edge network ensures minimal latency for your users.</p>
          </div>

          <div className="feature-card p-6 rounded-lg bg-nimbo-dark-lighter hover:bg-nimbo-dark-light transition-colors">
            <Network className="w-12 h-12 text-nimbo-orange mb-4" />
            <h3 className="text-xl font-semibold mb-2">Advanced Security</h3>
            <p className="text-gray-400">Enterprise-grade security with built-in DDoS protection.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
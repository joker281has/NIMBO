import React from 'react';
import { Link } from 'react-router-dom';
import AuthForm from '../components/AuthForm';
import GradientBackground from '../components/GradientBackground';

export default function SignUp() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center relative px-4">
      <GradientBackground />
      
      <div className="relative z-10 w-full max-w-md">
        <AuthForm mode="signup" />
        
        <p className="mt-6 text-center text-gray-400">
          Already have an account?{' '}
          <Link to="/signin" className="text-nimbo-orange hover:text-nimbo-orange-light">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  );
}
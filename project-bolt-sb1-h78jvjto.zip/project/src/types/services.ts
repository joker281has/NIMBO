export interface ServiceItem {
  name: string;
  description: string;
  path: string;
}
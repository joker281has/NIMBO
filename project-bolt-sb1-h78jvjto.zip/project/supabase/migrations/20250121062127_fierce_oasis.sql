/*
  # Create consultations table

  1. New Tables
    - `consultations`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `name` (text)
      - `email` (text)
      - `service` (text)
      - `preferred_date` (date)
      - `preferred_time` (time)
      - `message` (text)
      - `status` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `consultations` table
    - Add policies for:
      - Users can read their own consultations
      - Users can create consultations
      - Admin can read all consultations
*/

CREATE TABLE IF NOT EXISTS consultations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  name text NOT NULL,
  email text NOT NULL,
  service text NOT NULL,
  preferred_date date NOT NULL,
  preferred_time time NOT NULL,
  message text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE consultations ENABLE ROW LEVEL SECURITY;

-- Create secure policies
CREATE POLICY "Users can read own consultations"
  ON consultations
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create consultations"
  ON consultations
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "Admin can read all consultations"
  ON consultations
  FOR ALL
  TO authenticated
  USING (auth.jwt() ? 'is_admin');

-- Set up automatic timestamps
CREATE TRIGGER update_consultations_updated_at
  BEFORE UPDATE ON consultations
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();